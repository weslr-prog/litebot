"""
Fallback Universe - Curated list of mid-cap stocks for fallback screening
"""
from typing import List, Dict


# Curated Mid-Cap Universe (Market Cap $2B-$10B range)
# Last Updated: January 2026
# Expanded to 150+ stocks for better signal diversity
# These stocks are selected for:
# - Consistent trading volume
# - Mid-cap market cap range ($2B-$15B)
# - Sector diversification
# - Suitable volatility for D+1 trading

MID_CAP_FALLBACK = [
    # ═══════════════════════════════════════════════════════════════
    # AIRLINES & TRAVEL - High volatility, momentum plays
    # ═══════════════════════════════════════════════════════════════
    "AAL",      # American Airlines (~$8-9B)
    "ALK",      # Alaska Air (~$5-6B)
    "JBLU",     # JetBlue (~$2-3B)
    "SAVE",     # Spirit Airlines (~$2B)
    "UAL",      # United Airlines (~$20B)
    "DAL",      # Delta Airlines (~$30B)
    "LUV",      # Southwest Airlines (~$18B)
    
    # Cruise Lines
    "RCL",      # Royal Caribbean (~$35B)
    "CCL",      # Carnival (~$20B)
    "NCLH",     # Norwegian Cruise (~$8B)
    
    # Hotels & Leisure
    "MAR",      # Marriott (~$65B)
    "HLT",      # Hilton (~$50B)
    "H",        # Hyatt (~$12B)
    "EXPE",     # Expedia (~$18B)
    "BKNG",     # Booking Holdings (~$130B)
    
    # ═══════════════════════════════════════════════════════════════
    # RESTAURANTS & CONSUMER - Gap & Go candidates
    # ═══════════════════════════════════════════════════════════════
    "CAKE",     # Cheesecake Factory (~$2-3B)
    "TXRH",     # Texas Roadhouse (~$8-10B)
    "BJRI",     # BJ's Restaurants (~$1.5-2B)
    "PLAY",     # Dave & Buster's (~$1.5-2B)
    "CHUY",     # Chuy's Holdings (~$1B)
    "DIN",      # Dine Brands (~$1.5B)
    "DENN",     # Denny's (~$500M)
    "EAT",      # Brinker International (~$3B)
    "BLMN",     # Bloomin' Brands (~$2B)
    "WING",     # Wingstop (~$10B)
    "CMG",      # Chipotle (~$70B)
    "SBUX",     # Starbucks (~$100B)
    "MCD",      # McDonald's (~$200B)
    "YUM",      # Yum Brands (~$40B)
    "DRI",      # Darden (~$20B)
    
    # ═══════════════════════════════════════════════════════════════
    # RETAIL - Earnings momentum
    # ═══════════════════════════════════════════════════════════════
    "DKS",      # Dick's Sporting Goods (~$14B)
    "FIVE",     # Five Below (~$6-8B)
    "ULTA",     # Ulta Beauty (~$18B)
    "BOOT",     # Boot Barn (~$3-4B)
    "OLLI",     # Ollie's Bargain (~$3B)
    "GPS",      # Gap Inc (~$8B)
    "ANF",      # Abercrombie (~$7B)
    "AEO",      # American Eagle (~$4B)
    "URBN",     # Urban Outfitters (~$4B)
    "LULU",     # Lululemon (~$50B)
    "TJX",      # TJX Companies (~$120B)
    "ROST",     # Ross Stores (~$50B)
    "BURL",     # Burlington (~$15B)
    "WSM",      # Williams-Sonoma (~$18B)
    "RH",       # RH/Restoration Hardware (~$8B)
    "BBY",      # Best Buy (~$18B)
    "GME",      # GameStop (~$10B) - High volatility
    "CHWY",     # Chewy (~$12B)
    
    # ═══════════════════════════════════════════════════════════════
    # ENERGY - High beta, momentum
    # ═══════════════════════════════════════════════════════════════
    "RIG",      # Transocean (~$3-4B)
    "SWN",      # Southwestern Energy (~$6-7B)
    "AR",       # Antero Resources (~$6-8B)
    "RRC",      # Range Resources (~$6-7B)
    "CTRA",     # Coterra Energy (~$18B)
    "DVN",      # Devon Energy (~$25B)
    "MRO",      # Marathon Oil (~$15B)
    "APA",      # APA Corporation (~$10B)
    "OVV",      # Ovintiv (~$10B)
    "HAL",      # Halliburton (~$25B)
    "SLB",      # Schlumberger (~$55B)
    "BKR",      # Baker Hughes (~$35B)
    "VLO",      # Valero (~$45B)
    "MPC",      # Marathon Petroleum (~$55B)
    "PSX",      # Phillips 66 (~$50B)
    "XOM",      # Exxon (~$450B)
    "CVX",      # Chevron (~$280B)
    "OXY",      # Occidental (~$50B)
    "EOG",      # EOG Resources (~$70B)
    "PXD",      # Pioneer Natural (~$50B)
    
    # ═══════════════════════════════════════════════════════════════
    # TECH/GROWTH - Volatility & momentum
    # ═══════════════════════════════════════════════════════════════
    "PLUG",     # Plug Power (~$2-3B)
    "FSLR",     # First Solar (~$20B)
    "ENPH",     # Enphase (~$12B)
    "SEDG",     # SolarEdge (~$2-3B)
    "RUN",      # Sunrun (~$3B)
    "NOVA",     # Sunnova (~$1B)
    "STEM",     # Stem Inc (~$500M)
    "CHPT",     # ChargePoint (~$1B)
    "BLNK",     # Blink Charging (~$300M)
    "LCID",     # Lucid Motors (~$8B)
    "RIVN",     # Rivian (~$15B)
    "FSR",      # Fisker (if trading)
    "NKLA",     # Nikola (~$1B)
    "GOEV",     # Canoo (~$200M)
    "TSLA",     # Tesla (~$800B)
    "NIO",      # NIO (~$10B)
    "XPEV",     # XPeng (~$8B)
    "LI",       # Li Auto (~$25B)
    "F",        # Ford (~$45B)
    "GM",       # GM (~$50B)
    
    # Software & Cloud
    "SNOW",     # Snowflake (~$60B)
    "DDOG",     # Datadog (~$40B)
    "NET",      # Cloudflare (~$25B)
    "CRWD",     # CrowdStrike (~$75B)
    "ZS",       # Zscaler (~$30B)
    "OKTA",     # Okta (~$15B)
    "MDB",      # MongoDB (~$25B)
    "CFLT",     # Confluent (~$10B)
    "ESTC",     # Elastic (~$10B)
    "PATH",     # UiPath (~$10B)
    "DOCN",     # DigitalOcean (~$3B)
    "GTLB",     # GitLab (~$8B)
    "S",        # SentinelOne (~$7B)
    "TENB",     # Tenable (~$5B)
    "FRSH",     # Freshworks (~$5B)
    "ASAN",     # Asana (~$3B)
    "SUMO",     # Sumo Logic
    
    # Semiconductors
    "AMD",      # AMD (~$200B)
    "NVDA",     # NVIDIA (~$1.2T)
    "INTC",     # Intel (~$120B)
    "MU",       # Micron (~$100B)
    "MRVL",     # Marvell (~$60B)
    "AVGO",     # Broadcom (~$600B)
    "QCOM",     # Qualcomm (~$180B)
    "ON",       # ON Semi (~$30B)
    "SWKS",     # Skyworks (~$15B)
    "QRVO",     # Qorvo (~$8B)
    "SLAB",     # Silicon Labs (~$5B)
    "WOLF",     # Wolfspeed (~$3B)
    "AEHR",     # Aehr Test (~$1B)
    
    # ═══════════════════════════════════════════════════════════════
    # HEALTHCARE/BIOTECH - Event-driven volatility
    # ═══════════════════════════════════════════════════════════════
    "INCY",     # Incyte (~$12B)
    "VTRS",     # Viatris (~$11B)
    "MRNA",     # Moderna (~$20B)
    "BNTX",     # BioNTech (~$25B)
    "REGN",     # Regeneron (~$100B)
    "VRTX",     # Vertex (~$120B)
    "BIIB",     # Biogen (~$30B)
    "BMRN",     # BioMarin (~$15B)
    "ALNY",     # Alnylam (~$30B)
    "EXAS",     # Exact Sciences (~$10B)
    "DXCM",     # DexCom (~$40B)
    "ISRG",     # Intuitive Surgical (~$150B)
    "HOLX",     # Hologic (~$20B)
    "ALGN",     # Align Technology (~$18B)
    "PODD",     # Insulet (~$18B)
    "RARE",     # Ultragenyx (~$3B)
    "SRPT",     # Sarepta (~$10B)
    "NTLA",     # Intellia (~$2B) - CRISPR
    "CRSP",     # CRISPR Therapeutics (~$4B)
    "EDIT",     # Editas Medicine (~$500M)
    "BEAM",     # Beam Therapeutics (~$2B)
    "IONS",     # Ionis (~$8B)
    "ARWR",     # Arrowhead (~$5B)
    
    # Health Insurance & Services
    "OSCR",     # Oscar Health (~$3B)
    "CLVR",     # Clover Health (~$500M)
    "CLOV",     # Clover Health (alt ticker)
    "HIMS",     # Hims & Hers (~$3B)
    "AMWL",     # Amwell (~$500M)
    "TDOC",     # Teladoc (~$3B)
    
    # ═══════════════════════════════════════════════════════════════
    # INDUSTRIAL - Cyclical momentum
    # ═══════════════════════════════════════════════════════════════
    "CLF",      # Cleveland-Cliffs (~$6-8B)
    "X",        # US Steel (~$7-8B)
    "AA",       # Alcoa (~$6-8B)
    "NUE",      # Nucor (~$35B)
    "STLD",     # Steel Dynamics (~$20B)
    "FCX",      # Freeport-McMoRan (~$60B)
    "MP",       # MP Materials (~$3B)
    "LAC",      # Lithium Americas (~$2B)
    "ALB",      # Albemarle (~$15B)
    "SQM",      # Sociedad Quimica (~$15B)
    "LTHM",     # Livent (~$4B)
    "CAT",      # Caterpillar (~$180B)
    "DE",       # Deere (~$130B)
    "PCAR",     # Paccar (~$55B)
    "CMI",      # Cummins (~$45B)
    
    # ═══════════════════════════════════════════════════════════════
    # MEDIA/ENTERTAINMENT - Volatility on news
    # ═══════════════════════════════════════════════════════════════
    "SIRI",     # SiriusXM (~$15B)
    "PARA",     # Paramount (~$7-9B)
    "WBD",      # Warner Bros Discovery (~$20B)
    "LYV",      # Live Nation (~$25B)
    "SPOT",     # Spotify (~$60B)
    "RBLX",     # Roblox (~$25B)
    "TTWO",     # Take-Two (~$30B)
    "EA",       # Electronic Arts (~$40B)
    "ATVI",     # Activision (if still trading)
    "NFLX",     # Netflix (~$280B)
    "DIS",      # Disney (~$180B)
    "CMCSA",    # Comcast (~$150B)
    "FOXA",     # Fox Corp (~$15B)
    
    # ═══════════════════════════════════════════════════════════════
    # REAL ESTATE/HOUSING - Interest rate sensitive
    # ═══════════════════════════════════════════════════════════════
    "OPEN",     # Opendoor (~$1.5B)
    "Z",        # Zillow (~$10-12B)
    "RDFN",     # Redfin (~$1B)
    "COMP",     # Compass (~$2B)
    "DHI",      # DR Horton (~$50B)
    "LEN",      # Lennar (~$45B)
    "PHM",      # PulteGroup (~$25B)
    "TOL",      # Toll Brothers (~$10B)
    "MTH",      # Meritage Homes (~$8B)
    "KBH",      # KB Home (~$5B)
    "CCS",      # Century Communities (~$2B)
    
    # ═══════════════════════════════════════════════════════════════
    # FINANCIAL SERVICES - Fintech volatility
    # ═══════════════════════════════════════════════════════════════
    "HOOD",     # Robinhood (~$8-10B)
    "SOFI",     # SoFi (~$7-9B)
    "AFRM",     # Affirm (~$10-12B)
    "UPST",     # Upstart (~$3B)
    "LC",       # LendingClub (~$1B)
    "PYPL",     # PayPal (~$70B)
    "SQ",       # Block/Square (~$45B)
    "COIN",     # Coinbase (~$50B)
    "MARA",     # Marathon Digital (~$5B) - Crypto proxy
    "RIOT",     # Riot Platforms (~$3B) - Crypto proxy
    "CLSK",     # CleanSpark (~$3B) - Crypto proxy
    "HIVE",     # HIVE Blockchain
    "HUT",      # Hut 8 Mining
    
    # ═══════════════════════════════════════════════════════════════
    # MEME/HIGH-VOLATILITY SPECULATIVE
    # ═══════════════════════════════════════════════════════════════
    "AMC",      # AMC Entertainment (~$2B)
    "BB",       # BlackBerry (~$2B)
    "BBBY",     # Bed Bath & Beyond (if trading)
    "WISH",     # ContextLogic (~$200M)
    "CLOV",     # Clover Health
    "PLTR",     # Palantir (~$45B)
    "SOFI",     # SoFi
    "SPCE",     # Virgin Galactic (~$1B)
    "JOBY",     # Joby Aviation (~$4B)
    "ACHR",     # Archer Aviation (~$2B)
    "LILM",     # Lilium (~$500M)
    
    # ═══════════════════════════════════════════════════════════════
    # SPACE & DEFENSE
    # ═══════════════════════════════════════════════════════════════
    "RKLB",     # Rocket Lab (~$6B)
    "ASTR",     # Astra (~$100M)
    "PL",       # Planet Labs (~$1B)
    "ASTS",     # AST SpaceMobile (~$6B)
    "BKSY",     # BlackSky (~$300M)
    "RDW",      # Redwire (~$400M)
    "MNTS",     # Momentus (~$100M)
    "VORB",     # Virgin Orbit (if trading)
    
    # ═══════════════════════════════════════════════════════════════
    # CANNABIS (High volatility - use caution)
    # ═══════════════════════════════════════════════════════════════
    "TLRY",     # Tilray (~$1.5B)
    "CGC",      # Canopy Growth (~$500M-1B)
    "CRON",     # Cronos (~$1B)
    "ACB",      # Aurora Cannabis (~$300M)
    "SNDL",     # Sundial (~$500M)
]


# Sector-balanced diversified universe for more conservative fallback
DIVERSIFIED_MID_CAP = [
    # 4-5 stocks per sector, well-established mid-caps
    # Airlines/Travel
    "AAL", "ALK", "JBLU", "UAL", "NCLH",
    # Consumer/Restaurants
    "CAKE", "TXRH", "DKS", "FIVE", "ANF",
    # Energy
    "SWN", "AR", "RIG", "HAL", "SLB",
    # Technology
    "PLUG", "SEDG", "NET", "DDOG", "MDB",
    # Healthcare/Biotech
    "INCY", "VTRS", "NTLA", "MRNA", "OSCR",
    # Industrial
    "CLF", "AA", "X", "FCX", "MP",
    # Financial/Fintech
    "HOOD", "SOFI", "AFRM", "UPST", "COIN",
    # Media/Gaming
    "PARA", "RBLX", "SPOT", "EA",
    # Real Estate
    "OPEN", "Z", "DHI", "TOL",
    # Space/Defense
    "RKLB", "PL", "ASTS",
    # EV/Auto
    "LCID", "RIVN", "NIO", "F",
]


def get_fallback_universe(diversified: bool = False) -> List[str]:
    """
    Get the fallback universe of mid-cap stocks.
    
    Args:
        diversified: If True, return sector-balanced subset
                    If False, return full mid-cap list
    
    Returns:
        List of stock symbols
    """
    if diversified:
        return DIVERSIFIED_MID_CAP.copy()
    return MID_CAP_FALLBACK.copy()


def get_sector_stocks(sector: str) -> List[str]:
    """
    Get mid-cap stocks for a specific sector.
    
    Args:
        sector: Sector name (airlines, restaurants, energy, tech, etc.)
        
    Returns:
        List of stock symbols in that sector
    """
    sector_map: Dict[str, List[str]] = {
        "airlines": ["AAL", "ALK", "JBLU", "SAVE", "UAL", "DAL", "LUV"],
        "travel": ["RCL", "CCL", "NCLH", "MAR", "HLT", "H", "EXPE"],
        "restaurants": ["CAKE", "TXRH", "BJRI", "PLAY", "CHUY", "DIN", "EAT", "BLMN", "CMG"],
        "retail": ["DKS", "FIVE", "ULTA", "BOOT", "OLLI", "GPS", "ANF", "AEO", "URBN", "GME"],
        "energy": ["RIG", "SWN", "AR", "RRC", "CTRA", "DVN", "MRO", "HAL", "SLB", "OXY"],
        "tech": ["PLUG", "FSLR", "ENPH", "SEDG", "NET", "DDOG", "SNOW", "CRWD", "MDB"],
        "semiconductors": ["AMD", "NVDA", "MU", "MRVL", "ON", "SWKS", "QRVO", "WOLF"],
        "healthcare": ["INCY", "VTRS", "MRNA", "BNTX", "REGN", "BIIB", "DXCM"],
        "biotech": ["NTLA", "CRSP", "EDIT", "BEAM", "IONS", "ARWR", "SRPT", "RARE"],
        "industrial": ["CLF", "X", "AA", "NUE", "STLD", "FCX", "MP", "ALB"],
        "media": ["SIRI", "PARA", "WBD", "LYV", "SPOT", "RBLX", "NFLX", "DIS"],
        "realestate": ["OPEN", "Z", "RDFN", "DHI", "LEN", "PHM", "TOL"],
        "financial": ["HOOD", "SOFI", "AFRM", "UPST", "PYPL", "SQ", "COIN"],
        "crypto": ["MARA", "RIOT", "CLSK", "COIN"],
        "ev": ["LCID", "RIVN", "NIO", "XPEV", "LI", "TSLA", "F", "GM"],
        "space": ["RKLB", "PL", "ASTS", "BKSY", "JOBY", "ACHR"],
        "cannabis": ["TLRY", "CGC", "CRON", "ACB", "SNDL"],
        "meme": ["AMC", "GME", "BB", "PLTR", "SPCE"],
    }
    
    return sector_map.get(sector.lower(), [])
