"""
Fallback Universe - Curated list of mid-cap stocks for fallback screening
"""
from typing import List, Dict


# Curated Mid-Cap Universe (Market Cap $2B-$10B range)
# Last Updated: 2025
# These stocks are selected for:
# - Consistent trading volume
# - Mid-cap market cap range
# - Sector diversification
# - Suitable volatility for D+1 trading

MID_CAP_FALLBACK = [
    # Airlines - High volatility, momentum plays
    "AAL",      # American Airlines (~$8-9B)
    "ALK",      # Alaska Air (~$5-6B)
    "JBLU",     # JetBlue (~$2-3B)
    "SAVE",     # Spirit Airlines (~$2B)
    
    # Restaurants & Consumer - Gap & Go candidates
    "CAKE",     # Cheesecake Factory (~$2-3B)
    "TXRH",     # Texas Roadhouse (~$8-10B)
    "BJRI",     # BJ's Restaurants (~$1.5-2B)
    "PLAY",     # Dave & Buster's (~$1.5-2B)
    "CHUY",     # Chuy's Holdings (~$1B)
    "DIN",      # Dine Brands (~$1.5B)
    
    # Retail - Earnings momentum
    "DKS",      # Dick's Sporting Goods (~$14B - borderline large)
    "FIVE",     # Five Below (~$6-8B)
    "ULTA",     # Ulta Beauty (~$18B - large cap backup)
    "BOOT",     # Boot Barn (~$3-4B)
    "OLLI",     # Ollie's Bargain (~$3B)
    
    # Energy - High beta, momentum
    "RIG",      # Transocean (~$3-4B)
    "SWN",      # Southwestern Energy (~$6-7B)
    "AR",       # Antero Resources (~$6-8B)
    "RRC",      # Range Resources (~$6-7B)
    "CTRA",     # Coterra Energy (~$18B - large cap backup)
    
    # Tech/Growth - Volatility
    "PLUG",     # Plug Power (~$2-3B)
    "FSLR",     # First Solar (~$20B - large cap backup)
    "ENPH",     # Enphase (~$12B - borderline)
    "SEDG",     # SolarEdge (~$2-3B)
    
    # Healthcare/Biotech - Event-driven
    "HZNP",     # Horizon Therapeutics
    "SGEN",     # Seagen (if still trading)
    "INCY",     # Incyte (~$12B)
    "VTRS",     # Viatris (~$11B)
    
    # Industrial - Cyclical momentum
    "CLF",      # Cleveland-Cliffs (~$6-8B)
    "X",        # US Steel (~$7-8B)
    "AA",       # Alcoa (~$6-8B)
    "NUE",      # Nucor (~$35B - large cap backup)
    
    # Media/Entertainment
    "SIRI",     # SiriusXM (~$15B)
    "PARA",     # Paramount (~$7-9B)
    "WBD",      # Warner Bros Discovery (~$20B - large cap)
    "LYV",      # Live Nation (~$25B - large cap backup)
    
    # Real Estate/Housing
    "OPEN",     # Opendoor (~$1.5B)
    "Z",        # Zillow (~$10-12B)
    "RDFN",     # Redfin (~$1B)
    
    # Financial Services
    "HOOD",     # Robinhood (~$8-10B)
    "SOFI",     # SoFi (~$7-9B)
    "AFRM",     # Affirm (~$10-12B)
    
    # Cannabis (High volatility)
    "TLRY",     # Tilray (~$1.5B)
    "CGC",      # Canopy Growth (~$500M-1B)
]


# Sector-balanced diversified universe for more conservative fallback
DIVERSIFIED_MID_CAP = [
    # 2-3 stocks per sector, well-established mid-caps
    # Consumer Discretionary
    "CAKE", "TXRH", "DKS",
    # Industrials  
    "CLF", "AA", "X",
    # Energy
    "SWN", "AR", "RIG",
    # Technology
    "PLUG", "SEDG",
    # Healthcare
    "INCY", "VTRS",
    # Airlines
    "AAL", "ALK",
    # Financial
    "HOOD", "SOFI",
]


def get_fallback_universe(diversified: bool = False) -> List[str]:
    """
    Get the fallback universe of mid-cap stocks.
    
    Args:
        diversified: If True, return sector-balanced subset
                    If False, return full mid-cap list
    
    Returns:
        List of stock symbols
    """
    if diversified:
        return DIVERSIFIED_MID_CAP.copy()
    return MID_CAP_FALLBACK.copy()


def get_sector_stocks(sector: str) -> List[str]:
    """
    Get mid-cap stocks for a specific sector.
    
    Args:
        sector: Sector name (airlines, restaurants, energy, tech, etc.)
        
    Returns:
        List of stock symbols in that sector
    """
    sector_map: Dict[str, List[str]] = {
        "airlines": ["AAL", "ALK", "JBLU", "SAVE"],
        "restaurants": ["CAKE", "TXRH", "BJRI", "PLAY", "CHUY", "DIN"],
        "retail": ["DKS", "FIVE", "ULTA", "BOOT", "OLLI"],
        "energy": ["RIG", "SWN", "AR", "RRC", "CTRA"],
        "tech": ["PLUG", "FSLR", "ENPH", "SEDG"],
        "healthcare": ["HZNP", "SGEN", "INCY", "VTRS"],
        "industrial": ["CLF", "X", "AA", "NUE"],
        "media": ["SIRI", "PARA", "WBD", "LYV"],
        "financial": ["HOOD", "SOFI", "AFRM"],
    }
    
    return sector_map.get(sector.lower(), [])
