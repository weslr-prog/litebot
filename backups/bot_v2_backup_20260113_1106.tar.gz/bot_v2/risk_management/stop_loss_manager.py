"""
AI-powered dynamic stop loss and fast-exit management
Extracted from traders/short_cycle_trader.py
"""

import logging
import pandas as pd
from typing import Tuple

from bot_v2.config.trading_config import ShortCycleConfig
from bot_v2.models.signals import AISignal
from bot_v2.models.positions import ShortCyclePosition, PositionStatus


class AIStopLossManager:
    """AI-powered dynamic stop loss and fast-exit management"""
    
    def __init__(self, config: ShortCycleConfig):
        self.config = config
        self.logger = logging.getLogger(__name__ + ".AIStopLossManager")
        
        # Conservative parameters for short cycle (adjusted for ROI)
        self.max_stop_percent = 0.025  # 2.5% max stop for higher ROI potential
        self.fast_exit_threshold = 0.008  # 0.8% fast exit threshold
        self.atr_multiplier = 1.2  # More aggressive ATR-based stops
    
    def calculate_optimal_stop(self, signal: AISignal, market_data: pd.DataFrame) -> Tuple[float, float]:
        """Calculate optimal stop price and stop percentage"""
        try:
            entry_price = signal.entry_price
            if entry_price is None or market_data.empty:
                # Fallback to simple percentage stop
                stop_pct = self.max_stop_percent
                stop_price = entry_price * (1 - stop_pct)
                return stop_price, stop_pct
            
            # Calculate ATR-based stop
            high_low = market_data['high'] - market_data['low']
            high_close = abs(market_data['high'] - market_data['close'].shift(1))
            low_close = abs(market_data['low'] - market_data['close'].shift(1))
            true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            atr = true_range.tail(14).mean()
            
            # ATR-based stop
            atr_stop_distance = atr * self.atr_multiplier
            atr_stop_pct = atr_stop_distance / entry_price
            
            # Use minimum of percentage and ATR stop
            stop_pct = min(atr_stop_pct, self.max_stop_percent)
            stop_price = entry_price * (1 - stop_pct)
            
            self.logger.info(f"{signal.symbol}: ATR stop {atr_stop_pct:.1%}, final stop {stop_pct:.1%}")
            return stop_price, stop_pct
            
        except Exception as e:
            self.logger.error(f"Error calculating stop for {signal.symbol}: {e}")
            # Fallback to simple percentage
            stop_pct = self.max_stop_percent  
            stop_price = signal.entry_price * (1 - stop_pct)
            return stop_price, stop_pct
    
    def should_fast_exit(self, position: ShortCyclePosition, current_price: float) -> bool:
        """Check if position should fast-exit for capital recycling"""
        if position.status != PositionStatus.ENTERED:
            return False
        
        # Handle None values gracefully
        if current_price is None or position.entry_price is None:
            return False
        
        unrealized_pnl_pct = (current_price - position.entry_price) / position.entry_price
        unrealized_pnl_dollars = (current_price - position.entry_price) * position.position_size_shares
        
        # CRITICAL: Check max loss limit first (prevents $739 losses)
        if abs(unrealized_pnl_dollars) >= self.config.max_loss_per_trade_dollars:
            self.logger.warning(f"MAX LOSS LIMIT HIT: ${abs(unrealized_pnl_dollars):.2f} >= ${self.config.max_loss_per_trade_dollars}")
            return True
        
        return unrealized_pnl_pct <= -self.fast_exit_threshold
