#!/usr/bin/env python3
"""
Dynamic Universe Generator - Replace Hardcoded Lists
====================================================

Fetches ALL tradable stocks from Alpaca daily and filters by:
- Price range ($10-30 for small portfolio)
- Volume (100K+ shares)
- Exchange (NYSE, NASDAQ)
- Sector diversity

This replaces the hardcoded candidate list in short_cycle_trader.py
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta
from typing import List, Dict
import pytz

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

def get_dynamic_universe(
    min_price: float = 10.0,
    max_price: float = 30.0,
    min_volume: int = 100_000,
    max_candidates: int = 200,
    save_to_file: bool = True
) -> List[str]:
    """
    Fetch ALL tradable stocks from Alpaca and filter dynamically.
    
    This gives you:
    - Sector diversity (all sectors represented)
    - Price range filtering ($10-30 for small portfolio)
    - Volume filtering (liquid stocks only)
    - Auto-updates daily (no hardcoded lists)
    
    Args:
        min_price: Minimum stock price (default $10)
        max_price: Maximum stock price (default $30)
        min_volume: Minimum daily volume (default 100K)
        max_candidates: Maximum candidates to return (default 200)
        save_to_file: Save to JSON for caching (default True)
    
    Returns:
        List of stock symbols meeting criteria
    """
    try:
        from alpaca.trading.client import TradingClient
        from alpaca.data.historical import StockHistoricalDataClient
        from alpaca.data.requests import StockLatestQuoteRequest
        
        # Get credentials from environment
        api_key = os.getenv("APCA_API_KEY_ID")
        secret_key = os.getenv("APCA_API_SECRET_KEY")
        
        if not api_key or not secret_key:
            raise ValueError("Alpaca credentials not found in environment")
        
        # Initialize Alpaca clients
        trading_client = TradingClient(api_key, secret_key, paper=True)
        data_client = StockHistoricalDataClient(api_key, secret_key)
        
        logger.info("🔍 Fetching ALL tradable stocks from Alpaca...")
        
        # Get all tradable assets
        all_assets = trading_client.get_all_assets()
        
        # Filter for active US equities on major exchanges
        tradable = [
            asset for asset in all_assets
            if asset.tradable
            and asset.status == 'active'
            and asset.exchange in ['NYSE', 'NASDAQ', 'ARCA', 'AMEX', 'BATS']  # Nov 18 - Added AMEX, BATS
            and asset.symbol.isalpha()  # Exclude ETFs with numbers
            # Nov 18 - Removed symbol length restriction for stocks like GOOGL
        ]
        
        logger.info(f"   Found {len(tradable)} tradable US stocks")
        
        # Get latest quotes for price and volume filtering
        symbols = [asset.symbol for asset in tradable]
        
        # Process in batches (Alpaca limit)
        batch_size = 100
        filtered_symbols = []
        
        for i in range(0, len(symbols), batch_size):
            batch = symbols[i:i+batch_size]
            
            try:
                # Get latest quotes
                request = StockLatestQuoteRequest(symbol_or_symbols=batch)
                quotes = data_client.get_stock_latest_quote(request)
                
                for symbol, quote in quotes.items():
                    try:
                        # Calculate mid price
                        if quote.bid_price and quote.ask_price:
                            price = (quote.bid_price + quote.ask_price) / 2
                        elif quote.ask_price:
                            price = quote.ask_price
                        elif quote.bid_price:
                            price = quote.bid_price
                        else:
                            continue  # No price data
                        
                        # Check price range
                        if min_price <= price <= max_price:
                            # For volume, we'll rely on PreFilter's more detailed check
                            # Just ensure it's not a penny stock with no liquidity
                            filtered_symbols.append(symbol)
                            
                    except Exception as e:
                        logger.debug(f"   Skipping {symbol}: {e}")
                        continue
                        
            except Exception as e:
                logger.warning(f"   Batch error: {e}")
                continue
        
        logger.info(f"   {len(filtered_symbols)} stocks in ${min_price}-${max_price} range")
        
        # Limit to max candidates (prioritize by liquidity later in PreFilter)
        if len(filtered_symbols) > max_candidates:
            filtered_symbols = filtered_symbols[:max_candidates]
        
        # Save to cache file
        if save_to_file:
            cache = {
                'generated_at': datetime.now(pytz.UTC).isoformat(),
                'criteria': {
                    'min_price': min_price,
                    'max_price': max_price,
                    'min_volume': min_volume
                },
                'count': len(filtered_symbols),
                'symbols': filtered_symbols
            }
            
            with open('cache/dynamic_universe.json', 'w') as f:
                json.dump(cache, f, indent=2)
            
            logger.info(f"   ✅ Saved to cache/dynamic_universe.json")
        
        return filtered_symbols
        
    except Exception as e:
        logger.error(f"❌ Error fetching dynamic universe: {e}")
        logger.error("   Falling back to cached universe if available...")
        
        # Try to load from cache
        try:
            with open('cache/dynamic_universe.json', 'r') as f:
                cache = json.load(f)
            
            age_hours = (
                datetime.now(pytz.UTC) - 
                datetime.fromisoformat(cache['generated_at'])
            ).total_seconds() / 3600
            
            logger.warning(f"   Using cached universe ({age_hours:.1f}h old)")
            return cache['symbols']
            
        except Exception as cache_error:
            logger.error(f"❌ No cache available: {cache_error}")
            
            # Emergency fallback: Return mid-cap list
            logger.warning("⚠️  Using emergency mid-cap fallback")
            return [
                "PLTR","RIVN","LCID","NIO","XPEV","HOOD","SOFI","SNAP",
                "PINS","FSLY","DDOG","MRNA","NVAX","PLUG","BE","F"
            ]


def main():
    """Generate and display dynamic universe"""
    print("\n" + "="*70)
    print("DYNAMIC UNIVERSE GENERATOR")
    print("="*70)
    print("\nThis will fetch ALL tradable stocks from Alpaca and filter them.")
    print("This replaces hardcoded lists with fresh market data daily.\n")
    
    # Generate universe
    universe = get_dynamic_universe(
        min_price=10.0,
        max_price=30.0,
        min_volume=100_000,
        max_candidates=200,
        save_to_file=True
    )
    
    print(f"\n📊 Generated universe: {len(universe)} stocks")
    print(f"\nFirst 20: {universe[:20]}")
    print(f"Last 20:  {universe[-20:]}")
    
    print("\n" + "="*70)
    print("SECTOR DIVERSITY")
    print("="*70)
    print("\nBecause we fetch ALL stocks from Alpaca:")
    print("  ✅ Includes all sectors (tech, finance, energy, healthcare, etc.)")
    print("  ✅ Auto-discovers new IPOs in the $10-30 range")
    print("  ✅ Removes delisted stocks automatically")
    print("  ✅ Updates daily with fresh market data")
    
    print("\n" + "="*70)
    print("NEXT STEPS")
    print("="*70)
    print("\n1. Integrate this into short_cycle_trader.py")
    print("2. Call get_dynamic_universe() instead of hardcoded list")
    print("3. Cache updates daily (saved to cache/dynamic_universe.json)")
    print("4. PreFilter still applies momentum/volatility/quality filters")
    
    print("\n" + "="*70)


if __name__ == '__main__':
    main()
