"""
Unit tests for risk management modules
"""

import pytest
import pandas as pd
from datetime import datetime

from bot_v2.config.trading_config import ShortCycleConfig
from bot_v2.models.signals import AISignal
from bot_v2.models.positions import ShortCyclePosition, PositionStatus
from bot_v2.risk_management import (
    AIStopLossManager,
    AIConfidencePositionSizer,
    AIPredictiveRiskManager
)


class TestAIStopLossManager:
    """Test AIStopLossManager"""
    
    def test_initialization(self):
        """Test stop loss manager initialization"""
        config = ShortCycleConfig()
        manager = AIStopLossManager(config)
        
        assert manager.config == config
        assert manager.max_stop_percent == 0.025
        assert manager.fast_exit_threshold == 0.008
        assert manager.atr_multiplier == 1.2
    
    def test_calculate_optimal_stop_fallback(self):
        """Test stop calculation with empty market data (fallback)"""
        config = ShortCycleConfig()
        manager = AIStopLossManager(config)
        
        signal = AISignal(
            symbol="AAPL",
            action="BUY",
            confidence=0.75,
            entry_price=100.0,
            timestamp=datetime.now()
        )
        
        # Empty DataFrame should trigger fallback
        market_data = pd.DataFrame()
        stop_price, stop_pct = manager.calculate_optimal_stop(signal, market_data)
        
        assert stop_pct == 0.025  # max_stop_percent
        assert stop_price == 97.5  # 100 * (1 - 0.025)
    
    def test_should_fast_exit_loss_limit(self):
        """Test fast exit when max loss limit is hit"""
        config = ShortCycleConfig(max_loss_per_trade_dollars=20.0)
        manager = AIStopLossManager(config)
        
        position = ShortCyclePosition(
            symbol="AAPL",
            entry_price=100.0,
            position_size_shares=10.0,
            status=PositionStatus.ENTERED
        )
        
        # Current price down $2.50/share = $25 loss (exceeds $20 limit)
        current_price = 97.5
        
        assert manager.should_fast_exit(position, current_price) is True
    
    def test_should_fast_exit_threshold(self):
        """Test fast exit when threshold is exceeded"""
        config = ShortCycleConfig()
        manager = AIStopLossManager(config)
        
        position = ShortCyclePosition(
            symbol="AAPL",
            entry_price=100.0,
            position_size_shares=1.0,
            status=PositionStatus.ENTERED
        )
        
        # Price down 0.9% (exceeds 0.8% threshold)
        current_price = 99.1
        
        assert manager.should_fast_exit(position, current_price) is True
    
    def test_should_not_fast_exit_small_loss(self):
        """Test no fast exit for small loss"""
        config = ShortCycleConfig()
        manager = AIStopLossManager(config)
        
        position = ShortCyclePosition(
            symbol="AAPL",
            entry_price=100.0,
            position_size_shares=1.0,
            status=PositionStatus.ENTERED
        )
        
        # Price down 0.5% (below 0.8% threshold)
        current_price = 99.5
        
        assert manager.should_fast_exit(position, current_price) is False


class TestAIConfidencePositionSizer:
    """Test AIConfidencePositionSizer"""
    
    def test_initialization(self):
        """Test position sizer initialization"""
        config = ShortCycleConfig()
        sizer = AIConfidencePositionSizer(config)
        
        assert sizer.config == config
        assert sizer._vix_multiplier is None
        assert sizer._vix_fetch_time is None
    
    def test_calculate_position_size_high_confidence(self):
        """Test position sizing with high confidence signal"""
        config = ShortCycleConfig(max_risk_per_trade_dollars=20.0)
        sizer = AIConfidencePositionSizer(config)
        
        signal = AISignal(
            symbol="AAPL",
            action="BUY",
            confidence=0.80,  # High confidence
            entry_price=100.0,
            timestamp=datetime.now()
        )
        
        stop_price = 97.5  # 2.5% stop
        portfolio_value = 1000.0
        
        shares, position_value = sizer.calculate_position_size(
            signal, stop_price, portfolio_value
        )
        
        # High confidence should result in larger position
        assert shares > 0
        assert position_value > 0
        assert position_value <= config.max_position_dollars
    
    def test_calculate_position_size_invalid_prices(self):
        """Test position sizing rejects invalid prices"""
        config = ShortCycleConfig()
        sizer = AIConfidencePositionSizer(config)
        
        signal = AISignal(
            symbol="AAPL",
            action="BUY",
            confidence=0.75,
            entry_price=100.0,
            timestamp=datetime.now()
        )
        
        # Stop price higher than entry (invalid)
        stop_price = 105.0
        portfolio_value = 1000.0
        
        shares, position_value = sizer.calculate_position_size(
            signal, stop_price, portfolio_value
        )
        
        assert shares == 0
        assert position_value == 0.0


class TestAIPredictiveRiskManager:
    """Test AIPredictiveRiskManager"""
    
    def test_initialization(self):
        """Test risk manager initialization"""
        config = ShortCycleConfig()
        manager = AIPredictiveRiskManager(config)
        
        assert manager.config == config
        assert manager.max_correlation == 0.7
        assert manager.volatility_spike_threshold == 1.5
    
    def test_assess_portfolio_risk_approved(self):
        """Test portfolio risk assessment approves valid trades"""
        config = ShortCycleConfig()
        manager = AIPredictiveRiskManager(config)
        
        signals = [
            AISignal(symbol="AAPL", action="BUY", confidence=0.75, 
                    entry_price=100.0, timestamp=datetime.now())
        ]
        positions = []
        market_data = {}
        
        assessment = manager.assess_portfolio_risk(signals, positions, market_data)
        
        assert assessment["approved"] is True
        assert assessment["risk_score"] >= 0.0
        assert isinstance(assessment["warnings"], list)
        assert isinstance(assessment["vetoed_signals"], list)
    
    def test_assess_portfolio_risk_high_concentration(self):
        """Test portfolio risk warns on high sector concentration"""
        config = ShortCycleConfig()
        manager = AIPredictiveRiskManager(config)
        
        # All tech stocks (high concentration)
        signals = [
            AISignal(symbol="AAPL", action="BUY", confidence=0.75, 
                    entry_price=100.0, timestamp=datetime.now()),
            AISignal(symbol="MSFT", action="BUY", confidence=0.75, 
                    entry_price=100.0, timestamp=datetime.now())
        ]
        positions = []
        market_data = {}
        
        assessment = manager.assess_portfolio_risk(signals, positions, market_data)
        
        # Should have concentration warning
        assert len(assessment["warnings"]) > 0
        assert assessment["risk_score"] > 0.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
