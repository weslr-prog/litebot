#!/bin/bash
################################################################################
# bot_v2 Optimized Launcher
# Simplified Mean Reversion RSI trading bot
# Optimized for free data sources (yfinance) and peak efficiency
################################################################################

set -e  # Exit on error

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                              ║${NC}"
echo -e "${BLUE}║             bot_v2 OPTIMIZED - Paper Trading                 ║${NC}"
echo -e "${BLUE}║                                                              ║${NC}"
echo -e "${BLUE}║  Strategy: Mean Reversion RSI (56% WR)                       ║${NC}"
echo -e "${BLUE}║  Universe: 150 curated mid-cap stocks                        ║${NC}"
echo -e "${BLUE}║  Target: 2.5-3.5% weekly returns                             ║${NC}"
echo -e "${BLUE}║                                                              ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "bot_v2/config/prefilter_config.py" ]; then
    echo -e "${RED}❌ ERROR: Must run from litebotx-usb-deployment directory${NC}"
    echo -e "${YELLOW}   Try: cd /home/wes/Desktop/litebotx-usb-deployment${NC}"
    exit 1
fi

# Check Python environment
echo -e "${BLUE}🔍 Checking Python environment...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ ERROR: Python 3 not found${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Python found: $(python3 --version)${NC}"

# Check required files
echo ""
echo -e "${BLUE}🔍 Checking bot_v2 components...${NC}"

required_files=(
    "bot_v2/core/pre_filter.py"
    "bot_v2/data/mid_cap_universe.json"
    "bot_v2/config/prefilter_config.py"
    "data_loader.py"
    "config.py"
)

for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅ $file${NC}"
    else
        echo -e "${RED}❌ MISSING: $file${NC}"
        exit 1
    fi
done

# Check Alpaca credentials
echo ""
echo -e "${BLUE}🔍 Checking Alpaca credentials...${NC}"
if [ -z "$APCA_API_KEY_ID" ] || [ -z "$APCA_API_SECRET_KEY" ]; then
    echo -e "${YELLOW}⚠️  WARNING: Alpaca credentials not set in environment${NC}"
    echo -e "${YELLOW}   Checking config.py...${NC}"
    
    if grep -q "ALPACA_API_KEY" config.py && grep -q "ALPACA_SECRET_KEY" config.py; then
        echo -e "${GREEN}✅ Credentials found in config.py${NC}"
    else
        echo -e "${RED}❌ ERROR: No Alpaca credentials found${NC}"
        echo -e "${YELLOW}   Please set in config.py or environment variables${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✅ Alpaca credentials set in environment${NC}"
fi

# Show configuration
echo ""
echo -e "${BLUE}📊 Configuration Summary${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Strategy:${NC}       Mean Reversion RSI (56% WR)"
echo -e "${GREEN}Universe:${NC}       150 curated mid-cap stocks"
echo -e "${GREEN}PreFilter:${NC}      3-stage simplified (Price/Volume/Volatility)"
echo -e "${GREEN}Entry Window:${NC}   9:45 AM - 10:00 AM"
echo -e "${GREEN}Exit Time:${NC}      2:30 PM (forced)"
echo -e "${GREEN}Confidence:${NC}     50% threshold"
echo -e "${GREEN}Expected:${NC}       25-35 candidates, 3-5 signals daily"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"

# Run test before starting
echo ""
echo -e "${BLUE}🧪 Running PreFilter test...${NC}"
python3 test_bot_v2_optimized.py

if [ $? -ne 0 ]; then
    echo ""
    echo -e "${RED}❌ PreFilter test FAILED${NC}"
    echo -e "${YELLOW}   Please check configuration and try again${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ All tests passed!${NC}"
echo ""

# Countdown
echo -e "${YELLOW}Starting bot_v2 in:${NC}"
for i in 3 2 1; do
    echo -e "${YELLOW}   $i...${NC}"
    sleep 1
done

echo ""
echo -e "${GREEN}🚀 LAUNCHING bot_v2 Optimized...${NC}"
echo ""

# Launch (placeholder - will be updated with actual launcher)
# For now, show what would run
echo -e "${BLUE}Command:${NC} python3 -m bot_v2.launcher --paper"
echo ""
echo -e "${YELLOW}NOTE: Launcher script not yet implemented${NC}"
echo -e "${YELLOW}      Use test_bot_v2_optimized.py to validate PreFilter${NC}"
echo ""

# Instructions
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Next Steps:${NC}"
echo -e "  1. Run ${GREEN}test_bot_v2_optimized.py${NC} daily to validate PreFilter"
echo -e "  2. Expect ${GREEN}25-35 candidates${NC} from 150-stock universe"
echo -e "  3. Start bot by ${GREEN}8:30 AM${NC} to catch 9:00 AM gap scan"
echo -e "  4. Monitor ${GREEN}Mean Reversion signals${NC} (RSI ≤30 entries)"
echo -e "  5. Track ${GREEN}weekly returns${NC} (target 2.5-3.5%)"
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo ""

exit 0
