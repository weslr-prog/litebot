"""
AI Order Manager - Order submission, fill tracking, and execution
Extracted from ShortCycleTrader for modular architecture
"""
import logging
import datetime as dt
import pytz
import os
import json
from typing import Optional, Dict, Any

from bot_v2.models.positions import ShortCyclePosition
from bot_v2.models.enums import PositionStatus


class AIOrderManager:
    """
    Manages order execution, fill tracking, and trade logging.
    
    Responsibilities:
    - Submit buy/sell orders to broker (Alpaca)
    - Track order fills and timestamps
    - Log trade explanations for regulatory compliance
    - Handle order slippage tracking
    - Manage day trade enforcement (PDT compliance)
    """
    
    def __init__(self, config, execution_engine, day_trade_tracker=None, logger: Optional[logging.Logger] = None):
        """
        Initialize order manager
        
        Args:
            config: ShortCycleConfig with trading parameters
            execution_engine: Broker API (required for order execution)
            day_trade_tracker: Optional PDT tracker
            logger: Optional logger instance
        """
        self.config = config
        self.execution_engine = execution_engine
        self.day_trade_tracker = day_trade_tracker
        self.logger = logger or logging.getLogger(__name__)
    
    def execute_entry(self, signal):
        """
        Execute entry based on AISignal (converts to position and buys).
        
        Args:
            signal: AISignal object from signal generator
            
        Returns:
            ShortCyclePosition object if successful, None if failed
        """
        try:
            # Calculate position sizing
            position_size_dollars = signal.position_size_dollars or self.config.max_position_dollars
            entry_price = signal.entry_price
            
            # Debug logging
            self.logger.debug(
                f"{signal.symbol}: position_size_dollars={position_size_dollars} "
                f"(signal: {signal.position_size_dollars}, config: {self.config.max_position_dollars}), "
                f"entry_price={entry_price}"
            )
            
            shares = int(position_size_dollars / entry_price)
            
            if shares <= 0:
                self.logger.warning(
                    f"❌ Invalid position size for {signal.symbol}: {shares} shares "
                    f"(${position_size_dollars:.2f} / ${entry_price:.2f}) - "
                    f"signal.position_size_dollars={signal.position_size_dollars}"
                )
                return None
            
            # Calculate D+1 exit date
            entry_date = dt.datetime.now(pytz.UTC).date()
            exit_date = self._calculate_exit_date(entry_date)
            
            # Create position object
            position = ShortCyclePosition(
                symbol=signal.symbol,
                entry_date=entry_date,
                exit_date=exit_date,
                entry_price=entry_price,
                position_size_shares=shares,
                position_size_dollars=position_size_dollars,
                stop_price=signal.stop_price,
                target_price=signal.target_price,
                status=PositionStatus.PENDING,
                ai_signal=signal,
                max_risk_dollars=(entry_price - signal.stop_price) * shares
            )
            
            # Execute buy order
            success = self.execute_buy_order(position)
            
            if success:
                position.status = PositionStatus.ENTERED
                return position
            else:
                return None
            
        except Exception as e:
            self.logger.error(f"❌ execute_entry failed for {signal.symbol}: {e}")
            return None
    
    def _calculate_exit_date(self, entry_date: dt.date) -> dt.date:
        """Calculate D+1 exit date (next trading day)"""
        # Simple implementation: next calendar day
        # Could be enhanced with market calendar
        exit_date = entry_date + dt.timedelta(days=1)
        
        # Skip weekends
        while exit_date.weekday() >= 5:  # Saturday=5, Sunday=6
            exit_date += dt.timedelta(days=1)
        
        return exit_date
    
    def execute_buy_order(self, position) -> bool:
        """
        Execute a buy order for a new position.
        
        Args:
            position: ShortCyclePosition object with order details
            
        Returns:
            True if order succeeded, False otherwise
        """
        try:
            # Log the trade decision
            self._log_trade_explanation(position)
            
            # Day trade enforcement check
            if not self._check_day_trade_allowance(position):
                return False
            
            # Submit actual order to broker
            if self.execution_engine:
                order_result = self.execution_engine.submit_order(
                    symbol=position.symbol,
                    order_type='market_buy',
                    quantity=position.position_size_shares
                )
                
                if order_result:
                    self.logger.info(f"✅ BUY ORDER SUBMITTED: {position.symbol} {position.position_size_shares} shares")
                    self.logger.info(f"   Order ID: {order_result['order_id']}")
                    self.logger.info(f"   Status: {order_result['status']}")
                    
                    # Capture order metadata
                    if 'order_id' in order_result:
                        position.order_id = order_result['order_id']
                    
                    if 'submitted_at' in order_result and order_result['submitted_at']:
                        position.entry_timestamp = order_result['submitted_at']
                        self.logger.info(f"   Submitted: {order_result['submitted_at']}")
                    
                    if 'filled_at' in order_result and order_result['filled_at']:
                        position.filled_at = order_result['filled_at']
                        self.logger.info(f"   Filled: {order_result['filled_at']}")

                    # Record day trade if in intraday mode
                    self._record_day_trade_if_needed(position)
                    
                    # Update entry price with ACTUAL fill price
                    self._update_fill_price(position, order_result)
                    
                    return True
                else:
                    self.logger.error(f"❌ FAILED to submit buy order for {position.symbol}")
                    return False
            else:
                # Fallback to paper trade logging
                self.logger.info(f"📝 Paper trade: {position.symbol} {position.position_size_shares} shares")
                position.entry_timestamp = dt.datetime.now(pytz.UTC)
                return True
            
        except Exception as e:
            self.logger.error(f"Buy order execution failed: {e}")
            return False
    
    def execute_sell_order(self, position, exit_price: float, reason: str) -> bool:
        """
        Execute a sell order to exit a position.
        
        Args:
            position: ShortCyclePosition object to exit
            exit_price: Current market price
            reason: Exit reason string
            
        Returns:
            True if order succeeded, False otherwise
        """
        try:
            shares_to_exit = position.position_size_shares
            
            self.logger.info(
                f"🔚 Exiting {position.symbol}: {shares_to_exit} shares "
                f"entered {position.entry_date} (reason: {reason})"
            )
            
            # Submit actual SELL order to broker
            if self.execution_engine:
                order_result = self.execution_engine.submit_order(
                    symbol=position.symbol,
                    order_type='market_sell',
                    quantity=shares_to_exit
                )
                
                if order_result:
                    self.logger.info(f"✅ SELL ORDER SUBMITTED: {position.symbol} {shares_to_exit} shares")
                    self.logger.info(f"   Order ID: {order_result['order_id']}")
                    self.logger.info(f"   Status: {order_result['status']}")
                    
                    # Update exit price with ACTUAL fill price
                    filled_price = order_result.get('avg_fill_price') or order_result.get('filled_price') or order_result.get('fill_price')
                    if filled_price:
                        calculated_exit = exit_price
                        filled_exit = float(filled_price)
                        
                        # Calculate slippage
                        slippage_pct = abs(filled_exit - calculated_exit) / calculated_exit
                        
                        # Update exit_price with FILLED price
                        exit_price = filled_exit
                        
                        # Log slippage warning if significant
                        if slippage_pct > 0.02:  # >2% slippage
                            self.logger.warning(
                                f"⚠️ EXIT SLIPPAGE: {position.symbol} - "
                                f"Calculated: ${calculated_exit:.2f}, "
                                f"Filled: ${filled_exit:.2f} ({slippage_pct:.1%})"
                            )
                        else:
                            self.logger.info(
                                f"   Exit Fill: ${filled_exit:.2f} "
                                f"(calc: ${calculated_exit:.2f}, slip: {slippage_pct:.2%})"
                            )
                    
                    return True
                else:
                    self.logger.error(f"❌ FAILED to submit sell order for {position.symbol}")
                    return False
            else:
                # Fallback to paper trade logging
                self.logger.info(f"📝 Paper sell: {position.symbol} {shares_to_exit} shares")
                return True
                
        except Exception as e:
            self.logger.error(f"Sell order execution failed for {position.symbol}: {e}")
            return False
    
    def _check_day_trade_allowance(self, position) -> bool:
        """Check if day trade is allowed (PDT compliance)"""
        try:
            intraday_mode = getattr(self.config, 'max_hold_days', None) == 0
        except Exception:
            intraday_mode = False

        if intraday_mode and self.day_trade_tracker:
            remaining = self.day_trade_tracker.trades_remaining()
            
            try:
                now = dt.datetime.now(pytz.UTC)
                is_friday = now.weekday() == 4
            except Exception:
                now = dt.datetime.now()
                is_friday = now.weekday() == 4

            if is_friday:
                if remaining <= 0:
                    self.logger.warning(
                        f"❌ Friday: no emergency day trades remaining; skipping {position.symbol}"
                    )
                    return False
                else:
                    # Force same-day exit for Friday emergency trades
                    try:
                        position.exit_date = now.date()
                        self.logger.info(f"⚠️ Friday emergency entry for {position.symbol}; forcing same-day exit")
                    except Exception:
                        pass
            else:
                if remaining <= 0:
                    self.logger.warning(
                        f"❌ Day trade limit reached. Skipping {position.symbol}"
                    )
                    return False
        
        return True
    
    def _record_day_trade_if_needed(self, position):
        """Record day trade in tracker if in intraday mode"""
        try:
            intraday_mode = getattr(self.config, 'max_hold_days', None) == 0
            if intraday_mode and self.day_trade_tracker:
                when = position.filled_at if position.filled_at else dt.datetime.now(pytz.UTC)
                self.day_trade_tracker.record_trade(when)
        except Exception:
            pass
    
    def _update_fill_price(self, position, order_result: Dict):
        """Update position with actual fill price from broker"""
        filled_price = order_result.get('avg_fill_price') or order_result.get('filled_price') or order_result.get('fill_price')
        if filled_price:
            calculated_price = position.entry_price
            filled_price = float(filled_price)
            
            # Calculate slippage
            slippage_pct = abs(filled_price - calculated_price) / calculated_price
            
            # Update position with FILLED price
            position.entry_price = filled_price
            
            # Log slippage warning if significant
            if slippage_pct > 0.02:  # >2% slippage
                self.logger.warning(
                    f"⚠️ HIGH SLIPPAGE: {position.symbol} - "
                    f"Calculated: ${calculated_price:.2f}, "
                    f"Filled: ${filled_price:.2f} ({slippage_pct:.1%})"
                )
            else:
                self.logger.info(
                    f"   Fill Price: ${filled_price:.2f} "
                    f"(calc: ${calculated_price:.2f}, slip: {slippage_pct:.2%})"
                )
    
    def _log_trade_explanation(self, position):
        """Log detailed explanation of trade decision for regulatory compliance"""
        explanation = {
            "timestamp": dt.datetime.now().isoformat(),
            "symbol": position.symbol,
            "action": "ENTRY",
            "ai_decision": {
                "confidence": position.ai_signal.confidence,
                "features_used": position.ai_signal.features_used,
                "time_horizon": position.ai_signal.time_horizon_days
            },
            "position_sizing": {
                "shares": position.position_size_shares,
                "value": position.position_size_dollars,
                "risk": position.max_risk_dollars,
                "stop_distance": position.entry_price - position.stop_price
            },
            "schedule": {
                "entry_date": position.entry_date.isoformat(),
                "scheduled_exit": position.exit_date.isoformat()
            }
        }
        
        self._save_explanation_log(explanation)
    
    def log_exit_explanation(self, position):
        """Log exit decision explanation for regulatory compliance"""
        explanation = {
            "timestamp": dt.datetime.now().isoformat(),
            "symbol": position.symbol,
            "action": "EXIT",
            "exit_reason": position.exit_reason,
            "hold_days": position.hold_days,
            "performance": {
                "entry_price": position.entry_price,
                "exit_price": position.exit_price,
                "realized_pnl": position.realized_pnl,
                "return_pct": (position.exit_price / position.entry_price - 1) * 100
            }
        }
        
        self._save_explanation_log(explanation)
    
    def _save_explanation_log(self, explanation: Dict[str, Any]):
        """Save explanation to JSON log for regulatory compliance"""
        try:
            log_file = f"logs/trade_explanations_{dt.date.today().isoformat()}.json"
            os.makedirs("logs", exist_ok=True)
            
            with open(log_file, "a") as f:
                f.write(json.dumps(explanation, default=str) + "\n")
                
        except Exception as e:
            self.logger.error(f"Failed to save explanation log: {e}")
