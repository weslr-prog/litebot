"""
Simple PreFilter Configuration for bot_v2
Optimized for free data sources (yfinance) and peak efficiency

Design Philosophy:
- SIMPLE > COMPLEX with limited data (21 trading days)
- 3-stage filter (price, volume, volatility)
- NO breakout, momentum, gap detection (unreliable with free data)
- Focus on quality over quantity
"""

# Simple 3-Stage PreFilter Configuration
SIMPLE_PREFILTER_CONFIG = {
    # Stage 1: Price Range (affordable + liquid)
    # Dec 9: Changed from $5-$250 to $5-$50 for small portfolio ($982)
    # With $50 position size, we need stocks we can buy at least 1 share of
    'min_price': 5.0,           # $5 minimum (avoid penny stocks)
    'max_price': 50.0,          # $50 max (matches $50 position size)
    
    # Stage 2: Volume (basic liquidity)
    'min_volume': 100_000,      # 100K shares minimum
    'min_dollar_volume': 800_000,  # $800K minimum daily dollar volume
    
    # Stage 3: Volatility (tradeable range)
    'min_atr_pct': 0.015,       # 1.5% minimum daily range
    'max_atr_pct': 0.08,        # 8% maximum (avoid chaotic stocks)
    
    # Data Requirements
    'min_data_rows': 15,        # Minimum 15 days (yfinance limitation)
    
    # DISABLED Features (unreliable with 21 days data)
    'enable_breakout': False,        # Skip breakout detection
    'enable_momentum': False,        # Skip momentum detection
    'enable_gap_detection': False,   # Skip gap detection
    
    # Target Candidate Range (validated with 150-stock universe)
    'target_min_candidates': 20,     # Minimum for diversification
    'target_max_candidates': 40,     # Maximum for focus
    'enable_momentum': False,        # Skip momentum filter
    'enable_gap_detection': False,   # Skip gap-prone analysis
    'enable_regime': False,          # Skip regime adjustment
    
    # Output Targets
    'target_min_candidates': 20,     # Minimum candidates expected
    'target_max_candidates': 40      # Maximum candidates (quality control)
}


# Mean Reversion RSI Strategy Configuration (FOCUSED APPROACH)
# Updated Nov 27, 2025: RSI relaxed 30→35, volume 1.5→1.2 for more signals
MEAN_REVERSION_CONFIG = {
    # Entry Conditions
    'rsi_period': 7,                 # 7-period RSI (faster than 14)
    'rsi_entry_max': 35,             # Enter when RSI ≤ 35 (lightly oversold) - Nov 27 relaxed from 30
    'volume_confirmation': 1.2,      # 1.2x average volume minimum - Nov 27 confirmed (was 1.5 in signal_gen)
    'price_above_20sma': True,       # Trend filter (avoid falling knives)
    
    # Exit Conditions
    'rsi_exit_min': 70,              # Exit when RSI ≥ 70 (overbought)
    'profit_target_pct': 0.03,       # 3% profit target
    'stop_loss_pct': 0.025,          # 2.5% stop loss
    'force_exit_time': '14:30',      # D+1 exit at 2:30 PM (better liquidity)
    
    # Signal Quality
    'confidence_threshold': 0.50,    # 50% minimum confidence (vs 60%)
    'min_atr_pct': 0.015,           # 1.5% minimum volatility
    'max_atr_pct': 0.08,            # 8% maximum volatility
    
    # Expected Performance (Backtest Validated)
    'expected_win_rate': 0.56,       # 56% win rate
    'expected_avg_win': 0.032,       # 3.2% average win
    'expected_avg_loss': 0.025,      # 2.5% average loss
    'expected_weekly_return': 0.025  # 2.5% weekly return target
}


# Universe Configuration
UNIVERSE_CONFIG = {
    'source': 'mid_cap_universe.json',  # Curated 150-stock list
    'size': 150,                        # Total stocks in universe
    'market_cap_min': 2_000_000_000,    # $2B minimum (mid-cap floor)
    'market_cap_max': 10_000_000_000,   # $10B maximum (mid-cap ceiling)
    
    # Sector Allocation
    'sector_weights': {
        'technology': 0.40,             # 40% tech (high volatility)
        'consumer_discretionary': 0.20, # 20% consumer
        'healthcare_biotech': 0.15,     # 15% healthcare
        'financials': 0.10,             # 10% financials
        'energy_clean': 0.08,           # 8% energy
        'industrials': 0.04,            # 4% industrials
        'communication': 0.02,          # 2% communication
        'materials_commodities': 0.01   # 1% materials
    },
    
    # Quality Filters
    'min_avg_volume': 200_000,          # 200K shares/day minimum
    'min_institutional': 0.40,          # 40% minimum institutional ownership
    'max_institutional': 0.70           # 70% maximum (avoid too stable)
}


# Performance Optimization Settings
OPTIMIZATION_CONFIG = {
    # Timing
    'premarket_scan_time': '09:00',     # Gap scan (may skip if focused on mean reversion)
    'entry_window_start': '09:45',     # Primary entry window start
    'entry_window_end': '10:00',       # Primary entry window end
    'exit_monitoring_start': '10:00',  # Start monitoring exits
    'force_exit_time': '14:30',        # D+1 force exit (improved from 15:45)
    'friday_exit_time': '14:30',       # Friday exit (no weekend holds)
    
    # Execution
    'max_api_calls_per_scan': 150,     # Match universe size
    'expected_scan_time_sec': 5,       # Target: <5 seconds per scan
    'max_scan_time_sec': 10,           # Warning if >10 seconds
    
    # Risk Management
    'max_positions': 12,                # Max concurrent positions
    'max_position_size_pct': 0.083,    # 8.3% per position (1/12)
    'max_daily_loss_pct': 0.08,        # 8% daily loss limit
    'pdt_max_trades': 3,               # PDT limit (3 trades / 5 days)
    
    # Quality Control
    'min_signals_per_day': 5,          # Expect at least 5 signals
    'max_signals_per_day': 20,         # Warning if >20 signals
    'expected_candidates': 25          # Target candidate count
}


# Backtest Validation Thresholds
VALIDATION_CONFIG = {
    'min_win_rate': 0.54,              # Minimum acceptable win rate
    'min_weekly_return': 0.020,        # Minimum 2% weekly return
    'max_drawdown': 0.15,              # Maximum 15% drawdown
    'min_sharpe_ratio': 1.5,           # Minimum Sharpe ratio
    'min_trades_per_week': 15          # Minimum trade frequency
}


# Export all configs
__all__ = [
    'SIMPLE_PREFILTER_CONFIG',
    'MEAN_REVERSION_CONFIG',
    'UNIVERSE_CONFIG',
    'OPTIMIZATION_CONFIG',
    'VALIDATION_CONFIG'
]
