"""
Configuration module for bot_v2
Extracted from traders/short_cycle_trader.py
"""

from dataclasses import dataclass
from typing import List


@dataclass
class ShortCycleConfig:
    """Configuration for short-cycle trading system"""
    # Portfolio parameters (OPTION 3: Triple Frequency + 60% Win Rate - $1K Portfolio)
    # Dec 9: Reduced position size from $80 to $50 for $982 portfolio (allows ~19 positions)
    portfolio_value: float = None  # Will be fetched from Alpaca account (default: 1000.0 if fetch fails)
    daily_pool_percent: float = 0.30  # 30% Mon-Wed (conservative), open Thu-Fri (aggressive if unused)
    max_risk_per_trade_dollars: float = 20.0  # Risk per trade for position sizing (2% of $1K)
    max_position_dollars: float = 50.0  # $50 per position = ~19 positions possible ($982 ÷ $50)
    max_loss_per_trade_dollars: float = 20.0  # Hard stop at $20 per trade (2% of portfolio)
    
    # Market cap filter (mid-cap only)
    min_market_cap: float = 2_000_000_000  # $2B minimum (mid-cap floor)
    max_market_cap: float = 10_000_000_000  # $10B maximum (mid-cap ceiling)
    
    # Position parameters (OPTION 3: Triple frequency target)
    max_positions_per_day: int = 12  # Tripled from 4/month to 12/month (3x frequency)
    min_position_size_dollars: float = 10.0  # Minimum viable position for $1K account
    max_position_size_percent: float = 0.20  # 20% max position size (hard cap at $200 enforced)
    max_universe_size: int = 500  # Maximum number of symbols in trading universe (scaled for 3-strategy stack)
    
    # Diversification parameters
    max_positions_per_symbol_small: int = 2  # Max positions per symbol for portfolios < $100K
    max_positions_per_symbol_large: int = 3  # Max positions per symbol for portfolios > $100K
    max_concentration_percent_small: float = 0.35  # Max 35% of positions in one symbol (small portfolios)
    max_concentration_percent_large: float = 0.40  # Max 40% of positions in one symbol (large portfolios)
    portfolio_threshold_large: float = 100000.0  # Threshold for "large" portfolio diversification rules
    
    # Time parameters (3-Strategy Stack: Mean Reversion + Gap & Go + Double Bottom)
    max_hold_days: int = 2  # Maximum 2 days hold (D+1 forced exit)
    default_hold_days: int = 1  # Default to 1 day hold for D+1 strategy
    trading_days: List[str] = None  # All trading days (Mon-Fri)
    exit_time: str = "15:45"  # 15 minutes before close - HARD EXIT for all positions
    d_plus_one_force_exit_time: str = "15:45"  # Force exit D+1 positions at 3:45 PM
    friday_force_exit_time: str = "15:45"  # Force exit all Friday positions (no weekend holds)
    
    # PDT (Pattern Day Trader) management
    max_emergency_exits_per_week: int = 3  # 3 same-day exits allowed per week
    allow_friday_entries_with_unused_slots: bool = True  # Use unused emergency slots on Friday
    
    # Risk parameters (3-Strategy Stack: Mean Reversion + Gap & Go + Double Bottom)
    max_daily_loss_percent: float = 0.08  # 8% daily loss limit
    max_weekly_loss_percent: float = 0.15   # 15% weekly loss limit
    confidence_threshold: float = 0.60  # 60% minimum confidence (high selectivity)
    
    # Strategy-specific profit/stop targets (Nov 28: Updated for 2:1 R:R)
    mean_reversion_profit_target_pct: float = 0.04  # 4% profit target (Nov 28: raised from 3%)
    gap_and_go_profit_target_pct: float = 0.04  # 4% profit target for gap & go
    double_bottom_profit_target_pct: float = 0.05  # 5% profit target for double bottom
    mean_reversion_stop_loss_pct: float = 0.02  # 2% stop loss (Nov 28: tightened from 3%)
    gap_and_go_stop_loss_pct: float = 0.02  # 2% stop loss for gap & go
    double_bottom_stop_loss_pct: float = 0.02  # 2% stop loss for double bottom
    
    # Default targets (Nov 28: Updated for 2:1 R:R ratio)
    profit_target_pct: float = 0.04  # 4% default profit target (raised from 3%)
    stop_loss_pct: float = 0.02  # 2% default stop loss (tightened from 3%)
    
    # Trailing Stop Parameters (Mean Reversion Optimized)
    enable_trailing_stops: bool = True  # Enable trailing stop system
    trailing_trigger_pct: float = 0.02  # Activate after +2% gain (mean reversion optimal)
    trailing_distance_pct: float = 0.015  # Trail by 1.5% (mean reversion optimal)
    trailing_min_profit_pct: float = 0.01  # Lock in minimum +1.0% profit once activated
    trailing_update_interval_sec: int = 60  # Update trailing stops every 60 seconds
    
    # Backtesting parameters
    enable_forced_d1_exit: bool = True  # ENABLED - D+1 forced exits at 3:45 PM
    model_transaction_costs: bool = True
    commission_per_trade: float = 0.0  # Assume commission-free
    spread_bp: float = 5.0  # 5 basis points spread cost
    
    def __post_init__(self):
        if self.trading_days is None:
            self.trading_days = ["monday", "tuesday", "wednesday", "thursday"]
        
        # Fetch real account equity if not set
        if self.portfolio_value is None:
            self.portfolio_value = self._fetch_account_equity()
        
        # Calculate derived values
        self.daily_pool_dollars = self.portfolio_value * self.daily_pool_percent
        self.max_daily_loss_dollars = self.portfolio_value * self.max_daily_loss_percent
        self.max_weekly_loss_dollars = self.portfolio_value * self.max_weekly_loss_percent
    
    def _fetch_account_equity(self) -> float:
        """Fetch actual account equity from Alpaca"""
        try:
            import os
            from alpaca.trading.client import TradingClient
            
            api_key = os.getenv('APCA_API_KEY_ID')
            api_secret = os.getenv('APCA_API_SECRET_KEY')
            
            if not api_key or not api_secret:
                print("⚠️  Alpaca credentials not found, using default $1000")
                return 1000.0
            
            client = TradingClient(api_key, api_secret, paper=True)
            account = client.get_account()
            equity = float(account.equity)
            
            print(f"✅ Fetched account equity: ${equity:,.2f}")
            return equity
            
        except Exception as e:
            print(f"⚠️  Failed to fetch account equity: {e}")
            print("   Using default $1000")
            return 1000.0
    
    def validate(self) -> bool:
        """Validate configuration parameters"""
        errors = []
        
        # Portfolio validation
        if self.portfolio_value <= 0:
            errors.append("portfolio_value must be positive")
        if not 0 < self.daily_pool_percent <= 1.0:
            errors.append("daily_pool_percent must be between 0 and 1")
        if self.max_position_dollars > self.portfolio_value:
            errors.append("max_position_dollars cannot exceed portfolio_value")
        
        # Risk validation
        if not 0 < self.confidence_threshold <= 1.0:
            errors.append("confidence_threshold must be between 0 and 1")
        if self.max_daily_loss_percent < 0:
            errors.append("max_daily_loss_percent must be non-negative")
        
        # Position validation
        if self.max_positions_per_day < 1:
            errors.append("max_positions_per_day must be at least 1")
        if self.min_position_size_dollars > self.max_position_dollars:
            errors.append("min_position_size_dollars cannot exceed max_position_dollars")
        
        if errors:
            raise ValueError(f"Configuration validation failed: {', '.join(errors)}")
        
        return True
