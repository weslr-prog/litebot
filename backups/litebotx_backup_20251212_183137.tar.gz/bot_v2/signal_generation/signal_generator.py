"""
AI-powered signal generation with multi-source inputs and confidence scoring
Extracted from traders/short_cycle_trader.py
"""

import logging
import pandas as pd
from typing import List, Dict, Optional, Callable
from datetime import datetime

from bot_v2.config.trading_config import ShortCycleConfig
from bot_v2.models.signals import AISignal
from bot_v2.models.positions import PositionStatus


class AISignalGenerator:
    """AI-powered signal generation with multi-source inputs and confidence scoring"""
    
    def __init__(self, config: ShortCycleConfig, price_fetcher: Optional[Callable] = None, 
                 adaptive_params: bool = True):
        self.config = config
        self.logger = logging.getLogger(__name__ + ".AISignalGenerator")
        self.price_fetcher = price_fetcher  # Function to fetch real-time prices
        
        # Adaptive parameters
        self.adaptive_params_enabled = adaptive_params
        self.adaptive_manager = None
        if adaptive_params:
            try:
                from bot_v2.adaptive import AdaptiveParameterManager
                self.adaptive_manager = AdaptiveParameterManager(config)
                self.logger.info("✅ Adaptive parameter management ENABLED")
            except Exception as e:
                self.logger.warning(f"⚠️ Could not initialize adaptive params: {e}, using static")
                self.adaptive_params_enabled = False
        
        # Model placeholders (Sprint 1 implementation)
        self.model = None
        self.feature_pipeline = None
        
        # Market cap filtering
        self._market_cap_cache = {}  # Cache market caps to avoid repeated API calls
        
        # Enhanced quality scoring
        try:
            from intraday_quality_scorer import IntradayQualityScorer
            self.quality_scorer = IntradayQualityScorer()
            self.logger.info("✅ Enhanced quality scorer initialized")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize quality scorer: {e}")
            self.quality_scorer = None
        
        # News sentiment analyzer (Alpaca News API - free)
        try:
            from bot_v2.data_sources import NewsSentimentAnalyzer
            self.sentiment_analyzer = NewsSentimentAnalyzer()
            self.logger.info("✅ News sentiment analyzer initialized")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize sentiment analyzer: {e}")
            self.sentiment_analyzer = None
        
        # Dark pool detector (Alpaca IEX - free)
        try:
            from bot_v2.data_sources import DarkPoolDetector
            self.dark_pool_detector = DarkPoolDetector()
            self.logger.info("✅ Dark pool detector initialized")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize dark pool detector: {e}")
            self.dark_pool_detector = None
        
        # Earnings calendar filter (yfinance - free)
        try:
            from bot_v2.data_sources import EarningsCalendar
            self.earnings_calendar = EarningsCalendar(days_before=3, days_after=1)
            self.logger.info("✅ Earnings calendar initialized (skip 3d before, 1d after)")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize earnings calendar: {e}")
            self.earnings_calendar = None
        
        # Options flow analyzer (Alpaca Options API - free)
        try:
            from bot_v2.data_sources import OptionsFlowAnalyzer
            self.options_analyzer = OptionsFlowAnalyzer()
            self.logger.info("✅ Options flow analyzer initialized")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize options analyzer: {e}")
            self.options_analyzer = None
        
        # Entry quality screening (observation mode - logs but doesn't block)
        try:
            from entry_quality_screener import EntryQualityScreener
            self.entry_screener = EntryQualityScreener(strict_mode=False)
            self.screening_enabled = True  # Feature flag
            self.logger.info("✅ Entry quality screener initialized (OBSERVATION MODE)")
            self.logger.info("   📊 Screening will log quality but NOT block entries")
        except Exception as e:
            self.logger.warning(f"⚠️ Could not initialize entry screener: {e}")
            self.entry_screener = None
            self.screening_enabled = False
        
        # Volume threshold for signal generation
        self.volume_threshold = 1.0  # Minimum volume surge ratio
        
        # Temporary rule-based system for Sprint 0
        self.momentum_lookback = 4
    
    def _check_market_cap(self, symbol: str, data_loader) -> bool:
        """Check if symbol meets mid-cap requirements ($2B-$10B)"""
        try:
            # Check cache first
            if symbol in self._market_cap_cache:
                market_cap = self._market_cap_cache[symbol]
            else:
                # Fetch market cap from data source
                info = data_loader.get_stock_info(symbol)
                market_cap = info.get('marketCap', 0) if info else 0
                self._market_cap_cache[symbol] = market_cap
            
            # Check if within mid-cap range
            if market_cap < self.config.min_market_cap:
                self.logger.debug(f"❌ {symbol}: Market cap ${market_cap/1e9:.2f}B < ${self.config.min_market_cap/1e9:.0f}B (too small)")
                return False
            
            if market_cap > self.config.max_market_cap:
                self.logger.debug(f"❌ {symbol}: Market cap ${market_cap/1e9:.2f}B > ${self.config.max_market_cap/1e9:.0f}B (too large)")
                return False
            
            self.logger.debug(f"✅ {symbol}: Market cap ${market_cap/1e9:.2f}B (mid-cap)")
            return True
            
        except Exception as e:
            self.logger.warning(f"⚠️ {symbol}: Could not verify market cap: {e}, allowing by default")
            return True  # Allow if we can't verify (fail open)
        self.volume_threshold = 1.0
        
    def generate_signals(self, universe: List[str], market_data: Dict[str, pd.DataFrame], 
                        active_positions: Optional[List] = None) -> List[AISignal]:
        """Generate AI signals for given universe
        
        Args:
            universe: List of candidate symbols
            market_data: Historical price data for each symbol
            active_positions: List of currently active positions (for PDT validation)
        """
        # CRITICAL FIX #1: Validate entry candidates to prevent PDT violations
        validated_universe = self._validate_entry_candidates(universe, active_positions or [])
        
        signals = []
        
        for symbol in validated_universe:
            try:
                signal = self._analyze_symbol(symbol, market_data.get(symbol))
                if signal and signal.confidence >= self.config.confidence_threshold:
                    signals.append(signal)
            except Exception as e:
                self.logger.error(f"Error analyzing {symbol}: {e}")
        
        # Sort by confidence and limit to max positions
        signals.sort(key=lambda x: x.confidence, reverse=True)
        return signals[:self.config.max_positions_per_day]
    
    def generate_signal(self, symbol: str, market_data: pd.DataFrame, 
                       current_positions: Optional[List] = None) -> Optional[AISignal]:
        """Generate a single AI signal for a symbol (used for late-entry scanning)
        
        Args:
            symbol: Symbol to analyze
            market_data: Historical price data for the symbol
            current_positions: List of currently active positions (for PDT validation)
            
        Returns:
            AISignal if valid signal found, None otherwise
        """
        try:
            # Validate entry candidate (check PDT/D+1 rules)
            active_symbols = {pos.symbol.upper() for pos in (current_positions or [])
                            if pos.status == PositionStatus.ENTERED}
            
            if symbol.upper() in active_symbols:
                self.logger.debug(f"{symbol}: Skipped - active position exists (D+1 rule)")
                return None
            
            # Analyze symbol
            return self._analyze_symbol(symbol, market_data)
            
        except Exception as e:
            self.logger.error(f"Error generating signal for {symbol}: {e}")
            return None
    
    def _validate_entry_candidates(self, candidates: List[str], active_positions: List) -> List[str]:
        """
        CRITICAL: Remove any symbols that already have active positions (D+1 rule enforcement)
        This prevents PDT violations like the CRM issue on Oct 22.
        
        Args:
            candidates: List of candidate symbols to validate
            active_positions: List of currently active positions
        """
        active_symbols = {pos.symbol.upper() for pos in active_positions 
                         if pos.status == PositionStatus.ENTERED}
        
        valid = [sym for sym in candidates if sym.upper() not in active_symbols]
        
        filtered = set(c.upper() for c in candidates) - set(v.upper() for v in valid)
        if filtered:
            self.logger.warning(
                f"⚠️ D+1 Rule: Filtered {len(filtered)} symbols with active positions: {filtered}"
            )
            self.logger.warning(
                f"   These symbols cannot be re-entered until existing positions are closed"
            )
        
        return valid
    
    def _analyze_symbol(self, symbol: str, data: Optional[pd.DataFrame]) -> Optional[AISignal]:
        """Analyze individual symbol with enhanced quality scoring"""
        if data is None or len(data) < self.momentum_lookback + 1:
            return None

        try:
            # Initialize rejection tracking
            rejection_reasons = []
            
            # Normalize column names (handle both upper and lowercase)
            data_normalized = data.copy()
            data_normalized.columns = [col.lower() for col in data_normalized.columns]
            
            # TREND FILTER: 20-day SMA - Only buy stocks in uptrends (Nov 20 addition)
            # Nov 28: Loosened to within 2% of SMA (was exact) for more opportunities
            # Dec 4: Expanded to 3% to catch quality mean-reversion stocks
            # Dec 8: Expanded to 6% for mean reversion (oversold zone is -3% to -6% below SMA)
            # This prevents buying "cheap stocks that are actually crashing"
            if len(data_normalized) >= 20:
                sma_20 = data_normalized['close'].rolling(20).mean().iloc[-1]
                current_price = data_normalized['close'].iloc[-1]
                
                # Allow stocks within 6% of 20-SMA (Dec 8: expanded from 3% for mean reversion)
                sma_tolerance = sma_20 * 0.94  # 6% below SMA is acceptable for oversold bounce
                
                # Hard stop at -15% (broken stocks)
                hard_stop = sma_20 * 0.85
                
                if current_price < hard_stop:
                    price_below_pct = ((sma_20 - current_price) / sma_20) * 100
                    self.logger.info(
                        f"❌ REJECT {symbol}: Price ${current_price:.2f} more than 15% below 20-SMA ${sma_20:.2f} "
                        f"({price_below_pct:.1f}% below - broken stock, structural issues)"
                    )
                    return None
                    
                if current_price < sma_tolerance:
                    price_below_pct = ((sma_20 - current_price) / sma_20) * 100
                    self.logger.info(
                        f"❌ REJECT {symbol}: Price ${current_price:.2f} more than 6% below 20-SMA ${sma_20:.2f} "
                        f"({price_below_pct:.1f}% below - too far for mean reversion)"
                    )
                    return None
            
            # MOMENTUM CONFIRMATION: 5-day momentum filter (Nov 28 addition)
            # Dec 8: Loosened from -3% to -5% for mean reversion (utilities/staples drop deeper)
            # Prevents catching falling knives - but allows deeper oversold for quality stocks
            if len(data_normalized) >= 5:
                five_day_ago_price = data_normalized['close'].iloc[-5]
                current_price = data_normalized['close'].iloc[-1]
                five_day_momentum = (current_price - five_day_ago_price) / five_day_ago_price
                
                if five_day_momentum < -0.05:  # Still falling 5%+ over 5 days (was -3%)
                    self.logger.info(
                        f"❌ REJECT {symbol}: 5-day momentum {five_day_momentum*100:.1f}% (still falling too fast)"
                    )
                    return None
            
            # ═══════════════════════════════════════════════════════════════
            # 3-STRATEGY STACK FOR D+1 SWING TRADING (Nov 24, 2025)
            # ═══════════════════════════════════════════════════════════════
            # Based on comprehensive backtest (15 strategies, 2011-2024):
            # 
            # STRATEGY 1: Mean Reversion RSI - +2.62%, 56.2% WR, 0.92 tr/wk
            # STRATEGY 2: Gap & Go - +2.78%, 45.2% WR, 1.71 tr/wk
            # STRATEGY 3: Double Bottom - +3.17%, 46% WR, 1.11 tr/wk
            #
            # Expected on 500 stocks: 40-90 trades/week, 5-8% monthly return
            # ═══════════════════════════════════════════════════════════════
            
            # Import RSI calculation (modular approach)
            try:
                from core.indicators import calculate_rsi
            except ImportError:
                # Fallback for bot_v2 modular structure
                def calculate_rsi(data, window=14):
                    """Simple RSI calculation fallback"""
                    delta = data['close'].diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
                    rs = gain / loss
                    rsi = 100 - (100 / (1 + rs))
                    data_copy = data.copy()
                    data_copy['rsi'] = rsi
                    return data_copy
            
            # Calculate RSI(7) - optimal period from optimization
            df_with_rsi = calculate_rsi(data_normalized, window=7)
            current_rsi = df_with_rsi['rsi'].iloc[-1]
            
            # Get adaptive parameters if enabled
            if self.adaptive_params_enabled and self.adaptive_manager:
                adaptive_params = self.adaptive_manager.get_adaptive_parameters(symbol, data_normalized)
                rsi_entry_threshold = adaptive_params['rsi_entry']
                rsi_exit_threshold = adaptive_params['rsi_exit']
                confidence_threshold = adaptive_params['confidence_threshold']
                stop_loss_pct = adaptive_params['stop_loss_pct']
                profit_target_pct = adaptive_params['profit_target_pct']
                self.logger.debug(f"{symbol} adaptive: RSI entry={rsi_entry_threshold}, "
                                f"exit={rsi_exit_threshold}, conf={confidence_threshold:.2f}")
            else:
                # Static defaults (Nov 27: RSI relaxed 30→35 for more signals)
                rsi_entry_threshold = 35
                rsi_exit_threshold = 70
                confidence_threshold = self.config.confidence_threshold
                stop_loss_pct = self.config.stop_loss_pct
                profit_target_pct = self.config.profit_target_pct
            
            # Volume/Liquidity check (Dec 4: Changed from spike to liquidity)
            # OLD: Required 1.2x volume spike (day trading concept)
            # NEW: Check average dollar volume for liquidity (D+1 swing trading)
            avg_volume_20d = data_normalized['volume'].tail(20).mean()
            current_volume = data_normalized['volume'].iloc[-1]
            volume_surge = current_volume / avg_volume_20d if avg_volume_20d > 0 else 0
            volume_ratio = volume_surge / max(self.volume_threshold, 1e-6)
            volume_ratio_capped = min(volume_ratio, 2.5)
            
            # LIQUIDITY CHECK: Average dollar volume >= $500K/day (Dec 4 fix)
            # This ensures we can enter/exit positions without slippage
            avg_dollar_volume = avg_volume_20d * current_price
            is_liquid = avg_dollar_volume >= 500_000  # $500K minimum daily liquidity
            
            # ───────────────────────────────────────────────────────────────
            # STRATEGY 1: MEAN REVERSION RSI (PRIMARY)
            # ───────────────────────────────────────────────────────────────
            # Backtest: +2.62% (5 years), 56.2% win rate, 1.54 profit factor
            # Entry: RSI(7) <= 35 (oversold) + LIQUID stock
            # Exit: RSI >= 70 (overbought) OR +4% profit OR -2% stop
            # Dec 4: Removed volume spike requirement (irrelevant for D+1 swing)
            
            mean_reversion_signal = False
            mean_reversion_confidence = 0.0
            
            # Entry: RSI <= threshold (adaptive 25-40 based on regime)
            if current_rsi <= rsi_entry_threshold:
                # More oversold = higher confidence
                rsi_confidence = (rsi_entry_threshold - current_rsi) / 20.0
                # Dec 4: Volume spike no longer required, just use RSI confidence
                # Bonus confidence if volume is elevated (but not required)
                volume_bonus = min(volume_surge / 2.0, 0.2) if volume_surge > 1.0 else 0
                mean_reversion_confidence = min(rsi_confidence + volume_bonus, 1.0)
                mean_reversion_signal = is_liquid  # Only require liquidity, not volume spike
            
            # ───────────────────────────────────────────────────────────────
            # SINGLE STRATEGY: MEAN REVERSION RSI ONLY
            # ───────────────────────────────────────────────────────────────
            # Gap & Go and Double Bottom removed per optimization
            # Mean Reversion RSI: 56% win rate (proven winner)
            # Combined 3-stack: 51% win rate (5% dilution)
            
            # Use Mean Reversion as only strategy
            if mean_reversion_signal and mean_reversion_confidence >= self.config.confidence_threshold:
                best_strategy = 'MEAN_REVERSION_RSI'
                best_signal = True
                base_confidence = mean_reversion_confidence
            else:
                # No signal if Mean Reversion doesn't trigger
                rejection_reasons.append(f"No Mean Reversion signal (MR: {mean_reversion_signal}, conf: {mean_reversion_confidence:.2f})")
                return None  # Return None instead of continue (we're in a function, not a loop)
            
            # Set unused variables for compatibility with downstream code
            gap_and_go_signal = False
            gap_and_go_confidence = 0.0
            double_bottom_signal = False
            double_bottom_confidence = 0.0

            # Enhance with quality scoring if available
            if best_signal and self.quality_scorer and len(data_normalized) >= 100:
                try:
                    quality_result = self.quality_scorer.score_signal(
                        symbol=symbol,
                        current_data=data_normalized,
                        current_price=data_normalized['close'].iloc[-1]
                    )
                    
                    quality_score = quality_result['total_score']
                    quality_tier = quality_result['quality_tier']
                    
                    # Convert quality score (0-100) to confidence boost
                    # Strong quality (70+) → 2x-3x confidence
                    # Medium quality (40-70) → 1.5x-2x confidence
                    # Weak quality (<40) → 1x confidence (no boost)
                    quality_multiplier = 1.0 + (quality_score / 50.0)  # 0→1x, 50→2x, 100→3x
                    enhanced_confidence = min(base_confidence * quality_multiplier, 1.0)
                    
                    self.logger.info(
                        f"🎯 {symbol} [{best_strategy}]: base_conf={base_confidence:.3f}, "
                        f"quality={quality_score:.1f} ({quality_tier}), "
                        f"multiplier={quality_multiplier:.2f}x → final={enhanced_confidence:.3f}"
                    )
                    confidence = enhanced_confidence
                except Exception as e:
                    self.logger.debug(f"Quality scoring failed for {symbol}: {e}")
                    confidence = base_confidence
            else:
                confidence = base_confidence
            
            # ═══════════════════════════════════════════════════════════════
            # ENHANCED DATA SOURCES (Dec 12, 2025)
            # ═══════════════════════════════════════════════════════════════
            # Check earnings calendar FIRST - skip if earnings too close
            if self.earnings_calendar:
                try:
                    earnings_info = self.earnings_calendar.check_earnings(symbol)
                    if earnings_info['should_skip']:
                        self.logger.warning(f"❌ SKIP {symbol}: {self.earnings_calendar.format_earnings_log(symbol, earnings_info)}")
                        return None
                    elif earnings_info['has_earnings_soon']:
                        self.logger.info(f"   {self.earnings_calendar.format_earnings_log(symbol, earnings_info)}")
                except Exception as e:
                    self.logger.debug(f"{symbol}: Earnings check failed: {e}")
            
            # SENTIMENT & DARK POOL ENHANCEMENT (Nov 26, 2025)
            # ═══════════════════════════════════════════════════════════════
            # Check news sentiment and institutional activity (free Alpaca data)
            # Nov 28: Updated to use CONTRARIAN sentiment logic for mean reversion
            # For mean reversion: mildly bearish + dark pool = ideal (smart money buying dip)
            sentiment_boost = 0.0
            dark_pool_boost = 0.0
            options_boost = 0.0
            has_dark_pool_buying = False
            sentiment = None
            
            # Dark Pool Activity Check FIRST (needed for contrarian sentiment logic)
            if self.dark_pool_detector:
                try:
                    dark_pool_activity = self.dark_pool_detector.detect_institutional_activity(
                        symbol, hours_lookback=4
                    )
                    
                    # Log institutional activity
                    if dark_pool_activity['is_active']:
                        self.logger.info(f"   {self.dark_pool_detector.format_dark_pool_log(symbol, dark_pool_activity)}")
                    
                    # Check if dark pool shows buying
                    has_dark_pool_buying = dark_pool_activity['is_active'] and dark_pool_activity.get('confidence_boost', 0) > 0
                    
                    # Apply dark pool boost
                    dark_pool_boost = dark_pool_activity['confidence_boost']
                    
                except Exception as e:
                    self.logger.debug(f"{symbol}: Dark pool check failed: {e}")
            
            # News Sentiment Check (Alpaca News API) - Using CONTRARIAN logic for mean reversion
            if self.sentiment_analyzer:
                try:
                    sentiment = self.sentiment_analyzer.get_sentiment(symbol, hours_lookback=24)
                    
                    # Log sentiment
                    if sentiment['article_count'] > 0:
                        self.logger.info(f"   {self.sentiment_analyzer.format_sentiment_log(symbol, sentiment)}")
                    
                    # Check if we should skip trade (mean reversion: only skip on STRONG_BEAR)
                    if self.sentiment_analyzer.should_skip_trade(sentiment, strategy='mean_reversion'):
                        self.logger.warning(f"❌ SKIP {symbol}: Disaster news (STRONG_BEAR) - too risky")
                        return None
                    
                    # Use CONTRARIAN adjustment for mean reversion
                    # Mildly bearish + dark pool = BOOST (smart money buying dip)
                    # Very bullish = PENALTY (stock already rallying, not oversold)
                    sentiment_boost = self.sentiment_analyzer.get_contrarian_adjustment(
                        sentiment, has_dark_pool_buying=has_dark_pool_buying
                    )
                    
                    if has_dark_pool_buying and sentiment['signal'] == 'BEAR':
                        self.logger.info(f"   🎯 CONTRARIAN SETUP: {symbol} - Bearish news + Dark Pool buying = smart money dip buy")
                    
                except Exception as e:
                    self.logger.debug(f"{symbol}: Sentiment check failed: {e}")
            
            # Options Flow Check (Alpaca Options API)
            if self.options_analyzer:
                try:
                    options_flow = self.options_analyzer.analyze_flow(symbol)
                    
                    # Log options activity
                    if options_flow['institutional_signal'] != 'NEUTRAL':
                        self.logger.info(f"   {self.options_analyzer.format_flow_log(symbol, options_flow)}")
                    
                    # Check if we should skip (strong bearish flow)
                    if self.options_analyzer.should_skip_trade(options_flow):
                        self.logger.warning(f"❌ SKIP {symbol}: Strong bearish options flow (P/C={options_flow['put_call_ratio']:.2f})")
                        return None
                    
                    # Apply options boost
                    options_boost = options_flow['confidence_boost']
                    
                except Exception as e:
                    self.logger.debug(f"{symbol}: Options flow check failed: {e}")
            
            # Apply all confidence adjustments (sentiment + dark pool + options)
            if sentiment_boost != 0 or dark_pool_boost != 0 or options_boost != 0:
                original_confidence = confidence
                confidence = min(confidence + sentiment_boost + dark_pool_boost + options_boost, 1.0)
                confidence = max(confidence, 0.0)  # Can't go negative
                
                if confidence != original_confidence:
                    adjustment_type = "contrarian" if sentiment and sentiment['signal'] in ['BEAR', 'STRONG_BEAR'] else "standard"
                    self.logger.info(
                        f"   🔄 Confidence adjusted ({adjustment_type}): {original_confidence:.3f} → {confidence:.3f} "
                        f"(sentiment {sentiment_boost:+.3f}, dark pool {dark_pool_boost:+.3f}, options {options_boost:+.3f})"
                    )
            # ═══════════════════════════════════════════════════════════════

            # Strategy diagnostics logging
            if best_signal:
                self.logger.info(
                    f"🎯 {symbol} [{best_strategy}]: RSI={current_rsi:.1f}, "
                    f"vol_surge={volume_surge:.2f}x, confidence={confidence:.3f}"
                )
                
                # Log strategy-specific details
                if best_strategy == 'GAP_AND_GO' and len(data_normalized) >= 2:
                    today_open = data_normalized['open'].iloc[-1]
                    yesterday_close = data_normalized['close'].iloc[-2]
                    gap_pct = (today_open - yesterday_close) / yesterday_close
                    self.logger.info(f"   📈 Gap: {gap_pct*100:+.1f}% (${yesterday_close:.2f} → ${today_open:.2f})")
                elif best_strategy == 'DOUBLE_BOTTOM' and len(data_normalized) >= 20:
                    recent_lows = data_normalized['low'].tail(20)
                    min_low = recent_lows.min()
                    support_tests = (recent_lows <= min_low * 1.02).sum()
                    self.logger.info(f"   🔄 Support tests: {support_tests} at ${min_low:.2f}")
                elif best_strategy == 'MEAN_REVERSION_RSI':
                    self.logger.info(f"   📉 RSI oversold: {current_rsi:.1f} (threshold: 30)")

            # Entry signal generation (if best strategy found)
            if best_signal and confidence >= self.config.confidence_threshold:
                # Entry quality screening (observation mode - log but don't block)
                if self.screening_enabled and self.entry_screener:
                    try:
                        # Note: momentum_score not calculated for all strategies
                        # Using RSI as proxy for screening
                        should_enter, quality_level, reason = self.entry_screener.screen_entry(
                            symbol=symbol,
                            momentum=0.0,  # Not used for mean reversion/double bottom
                            volume_surge=volume_surge,
                            sector=None  # TODO: Add sector lookup
                        )
                        
                        # Log screening result with emoji indicators
                        quality_emoji = {
                            'IDEAL': '🟢',
                            'GOOD': '🟡', 
                            'ACCEPTABLE': '🟠',
                            'REJECT': '🔴'
                        }.get(quality_level, '⚪')
                        
                        self.logger.info(
                            f"📊 ENTRY SCREENING: {symbol} [{best_strategy}] → {quality_emoji} {quality_level}: {reason}"
                        )
                        
                        # Observation mode: Log only, don't block trades
                        # Future: Add soft enforcement option (block only REJECT quality)
                        
                    except Exception as e:
                        self.logger.warning(f"⚠️ Entry screening failed for {symbol}: {e}")
                
                # CRITICAL FIX (Nov 19): Get REAL-TIME price from Alpaca, not cached historical data
                # Bug discovered: MSTZ showed $10.59 (cached), actual fill $12.56 (18.6% slippage!)
                # Solution: Always fetch live price before creating signal
                realtime_price = None
                if self.price_fetcher:
                    try:
                        realtime_price = self.price_fetcher(symbol)
                    except Exception as e:
                        self.logger.debug(f"Price fetcher failed for {symbol}: {e}")
                
                if realtime_price is None:
                    # Fallback to historical if real-time fetch fails
                    realtime_price = data_normalized['close'].iloc[-1]
                    self.logger.debug(f"{symbol}: Using cached price ${realtime_price:.2f}")
                else:
                    # Log price source for transparency
                    cached_price = data_normalized['close'].iloc[-1]
                    price_diff_pct = abs(realtime_price - cached_price) / cached_price
                    if price_diff_pct > 0.02:  # >2% difference
                        self.logger.warning(
                            f"⚠️ {symbol}: Price mismatch - cached: ${cached_price:.2f}, "
                            f"real-time: ${realtime_price:.2f} ({price_diff_pct:.1%} diff)"
                        )
                
                # Calculate stop loss and profit target based on strategy
                # (if not already set by adaptive parameters)
                if not self.adaptive_params_enabled:
                    if best_strategy == "MEAN_REVERSION":
                        stop_loss_pct = self.config.mean_reversion_stop_loss_pct
                        profit_target_pct = self.config.mean_reversion_profit_target_pct
                    elif best_strategy == "GAP_AND_GO":
                        stop_loss_pct = self.config.gap_and_go_stop_loss_pct
                        profit_target_pct = self.config.gap_and_go_profit_target_pct
                    elif best_strategy == "DOUBLE_BOTTOM":
                        stop_loss_pct = self.config.double_bottom_stop_loss_pct
                        profit_target_pct = self.config.double_bottom_profit_target_pct
                    else:
                        stop_loss_pct = self.config.stop_loss_pct
                        profit_target_pct = self.config.profit_target_pct
                
                # Calculate actual prices
                stop_price = realtime_price * (1 - stop_loss_pct)
                target_price = realtime_price * (1 + profit_target_pct)
                
                # Calculate position size
                position_size_dollars = self.config.max_position_dollars
                
                # Create signal with strategy-specific metadata
                signal = AISignal(
                    symbol=symbol,
                    action="BUY",
                    confidence=confidence,
                    time_horizon_days=1.5,
                    entry_price=realtime_price,
                    stop_price=stop_price,
                    target_price=target_price,
                    position_size_dollars=position_size_dollars,
                    signal_timestamp=datetime.now(),
                    features_used={
                        "rsi": current_rsi,
                        "volume_surge": volume_surge,
                        "volume_ratio": volume_ratio,
                        "base_confidence": base_confidence,
                        "quality_enhanced": confidence > base_confidence,
                        "strategy": best_strategy.lower(),
                        "entry_reason": f"{best_strategy}_SIGNAL",
                        # Strategy-specific features
                        "mean_reversion_conf": mean_reversion_confidence,
                        "gap_and_go_conf": gap_and_go_confidence,
                        "double_bottom_conf": double_bottom_confidence,
                        # Adaptive parameters
                        "adaptive_stop_loss_pct": stop_loss_pct if self.adaptive_params_enabled else None,
                        "adaptive_profit_target_pct": profit_target_pct if self.adaptive_params_enabled else None,
                        "adaptive_rsi_entry": rsi_entry_threshold if self.adaptive_params_enabled else None,
                        "adaptive_rsi_exit": rsi_exit_threshold if self.adaptive_params_enabled else None,
                        # Sentiment & Dark Pool (Nov 26, 2025)
                        "sentiment_boost": sentiment_boost if self.sentiment_analyzer else 0.0,
                        "dark_pool_boost": dark_pool_boost if self.dark_pool_detector else 0.0,
                        "sentiment_signal": sentiment.get('signal', 'N/A') if self.sentiment_analyzer else 'N/A',
                        "dark_pool_signal": dark_pool_activity.get('institutional_signal', 'N/A') if self.dark_pool_detector else 'N/A'
                    }
                )
                
                # Store adaptive parameters in signal for exit manager
                if self.adaptive_params_enabled:
                    signal.adaptive_stop_loss_pct = stop_loss_pct
                    signal.adaptive_profit_target_pct = profit_target_pct
                    signal.adaptive_rsi_exit = rsi_exit_threshold
                
                return signal
            else:
                # DETAILED REJECTION LOGGING
                # Show exactly why no signal was generated
                rejection_reasons = []
                
                if not best_signal:
                    rejection_reasons.append("No strategy triggered")
                    rejection_reasons.append(f"(MR: {mean_reversion_signal}, GG: {gap_and_go_signal}, DB: {double_bottom_signal})")
                
                if best_signal and confidence < self.config.confidence_threshold:
                    rejection_reasons.append(f"Confidence {confidence:.3f} < {self.config.confidence_threshold:.3f}")
                
                rejection_msg = " AND ".join(rejection_reasons)
                self.logger.debug(f"   ❌ REJECT {symbol}: {rejection_msg}")
                
        except Exception as e:
            self.logger.error(f"Error in symbol analysis for {symbol}: {e}")

        return None
