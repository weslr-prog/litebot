#!/usr/bin/env python3
"""
Bot V2 DataLoader
Standalone data loader for bot_v2 - fetches historical OHLCV and current prices.
Uses yfinance as primary source with optional Alpaca IEX validation.
Logs to bot_v2/logs/ directory.
"""
from __future__ import annotations
import os
import pandas as pd
import datetime as dt
from typing import Dict, List, Optional
import logging
from pathlib import Path

try:
    import yfinance as yf
except Exception:
    yf = None

# Optional Alpaca Market Data (IEX) support
try:
    from alpaca.data import StockMarketDataClient, StockLatestTradeRequest
except Exception:
    StockMarketDataClient = None
    StockLatestTradeRequest = None

# Setup bot_v2 specific logging
logger = logging.getLogger('bot_v2.data_loader')


class DataLoader:
    """
    Standalone data loader for bot_v2
    Fetches market data from yfinance with optional Alpaca IEX validation
    """
    
    def __init__(self, enable_multi_source_validation: bool = True):
        """
        Initialize DataLoader
        
        Args:
            enable_multi_source_validation: Enable cross-validation with Alpaca IEX
        """
        self._yf_available = yf is not None
        
        # Initialize Alpaca Market Data client if credentials are available
        self._alpaca_client = None
        api_key = os.getenv("APCA_API_KEY_ID")
        secret_key = os.getenv("APCA_API_SECRET_KEY")
        
        if api_key and secret_key and StockMarketDataClient is not None:
            try:
                self._alpaca_client = StockMarketDataClient(api_key, secret_key)
                logger.info("✅ Alpaca Market Data client initialized (IEX)")
            except Exception as e:
                logger.warning(f"⚠️  Failed to init Alpaca Market Data client: {e}")
        
        # Initialize multi-source validation
        self._multi_source_loader = None
        if enable_multi_source_validation:
            try:
                from bot_v2.data_sources import MultiSourceDataLoader
                self._multi_source_loader = MultiSourceDataLoader(yfinance_loader=self)
                logger.info("✅ Multi-source data validation enabled (yfinance + Alpaca IEX)")
            except Exception as e:
                logger.debug(f"Multi-source validation not available: {e}")

    def get_historical_data(
        self, 
        symbol: str, 
        days: int = 30, 
        use_cache: bool = False
    ) -> pd.DataFrame:
        """
        Get historical OHLCV data for a symbol
        
        Args:
            symbol: Stock symbol
            days: Number of trading days to fetch
            use_cache: Not used (kept for API compatibility)
            
        Returns:
            DataFrame with columns: date, open, high, low, close, volume
        """
        # Try multi-source validation first (if enabled)
        if self._multi_source_loader:
            try:
                validated_data = self._multi_source_loader.get_validated_data(
                    symbol, 
                    days=days, 
                    validate=True
                )
                if validated_data is not None and not validated_data.empty:
                    # Ensure 'date' column exists
                    if 'date' not in validated_data.columns:
                        validated_data = validated_data.reset_index()
                        # Try to find a datetime column to rename
                        for col in validated_data.columns:
                            if col in ['Date', 'timestamp', 'Timestamp', 'index']:
                                validated_data = validated_data.rename(columns={col: 'date'})
                                break
                        # If still no 'date', use index
                        if 'date' not in validated_data.columns:
                            validated_data['date'] = pd.to_datetime(validated_data.index)
                    
                    # Ensure date is datetime type
                    validated_data['date'] = pd.to_datetime(validated_data['date'])
                    
                    return validated_data
            except Exception as e:
                logger.debug(f"{symbol}: Multi-source validation failed, falling back to yfinance: {e}")
        
        # Fallback to standard yfinance fetch
        if not self._yf_available:
            logger.warning("⚠️  yfinance not available; returning empty DataFrame")
            return pd.DataFrame()

        # Request a longer calendar range to account for weekends/holidays
        calendar_days = max(int(days * 2.2), days + 10)
        start = (dt.datetime.utcnow() - dt.timedelta(days=calendar_days)).date()
        end = dt.datetime.utcnow().date()

        try:
            tkr = yf.Ticker(symbol)
            hist = tkr.history(start=start, end=end, interval="1d", auto_adjust=False)
            
            if hist is None or hist.empty:
                return pd.DataFrame()

            # Normalize schema
            hist = hist.rename(columns={
                'Open': 'open', 
                'High': 'high', 
                'Low': 'low', 
                'Close': 'close', 
                'Volume': 'volume'
            })
            
            # Ensure required columns present
            required_cols = ['open', 'high', 'low', 'close', 'volume']
            for c in required_cols:
                if c not in hist.columns:
                    logger.warning(f"{symbol}: Missing column '{c}'")
                    return pd.DataFrame()

            # Ensure a date column
            hist = hist.reset_index()
            
            # yfinance index column can be DatetimeIndex named 'Date'
            if 'Date' in hist.columns:
                hist = hist.rename(columns={'Date': 'date'})
            elif 'date' not in hist.columns:
                # Try to coerce any datetime index to 'date'
                if isinstance(hist.index, pd.DatetimeIndex):
                    hist['date'] = hist.index
                    hist = hist.reset_index(drop=True)
                else:
                    hist['date'] = pd.to_datetime('today')

            # Keep only required columns, sort, and return last N trading rows
            hist = hist[['date', 'open', 'high', 'low', 'close', 'volume']].copy()
            hist['date'] = pd.to_datetime(hist['date'])
            hist = hist.sort_values('date')
            hist = hist.dropna(subset=['open', 'high', 'low', 'close', 'volume'])
            
            # Return last N rows (trading days)
            if len(hist) > days:
                hist = hist.tail(days)
                
            return hist.reset_index(drop=True)
            
        except Exception as e:
            logger.error(f"❌ Error fetching historical data for {symbol}: {e}", exc_info=False)
            return pd.DataFrame()

    def get_historical_data_bulk(
        self, 
        symbols: List[str], 
        days: int = 30
    ) -> Dict[str, pd.DataFrame]:
        """
        Get historical data for multiple symbols
        
        Args:
            symbols: List of stock symbols
            days: Number of trading days to fetch
            
        Returns:
            Dictionary mapping symbol to DataFrame
        """
        out: Dict[str, pd.DataFrame] = {}
        for symbol in symbols:
            df = self.get_historical_data(symbol, days=days)
            if isinstance(df, pd.DataFrame) and not df.empty:
                out[symbol] = df
        return out

    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current/latest price for a symbol
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Current price or None if unavailable
        """
        # Preferred: Alpaca Market Data (IEX) if configured
        if self._alpaca_client is not None and StockLatestTradeRequest is not None:
            try:
                req = StockLatestTradeRequest(symbol_or_symbols=symbol)
                resp = self._alpaca_client.get_latest_trade(req)
                
                # resp can be a dict (for multi-symbol) or a Trade object (single)
                price = None
                if hasattr(resp, 'price'):
                    price = resp.price
                elif isinstance(resp, dict):
                    obj = resp.get(symbol) or (next(iter(resp.values())) if resp else None)
                    price = getattr(obj, 'price', None) if obj is not None else None
                    
                if price is not None:
                    return float(price)
                    
            except Exception as e:
                logger.debug(f"{symbol}: Alpaca latest trade failed: {e}")

        # Fallback: yfinance last price/close
        if not self._yf_available:
            return None
            
        try:
            tkr = yf.Ticker(symbol)
            
            # Try fast_info first (faster)
            info = getattr(tkr, 'fast_info', None)
            if info and hasattr(info, 'last_price') and info.last_price:
                return float(info.last_price)
                
            # Fallback to recent history
            hist = tkr.history(period='5d', interval='1d').tail(1)
            if not hist.empty:
                close_val = hist['Close'].iloc[-1] if 'Close' in hist.columns else hist['close'].iloc[-1]
                return float(close_val)
                
        except Exception as e:
            logger.debug(f"{symbol}: yfinance price fetch failed: {e}")
            return None
            
        return None

    def get_stock_info(self, symbol: str) -> Optional[Dict]:
        """
        Get stock info including market cap, sector, etc.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Dictionary with stock info or None if unavailable
        """
        if not self._yf_available:
            return None
            
        try:
            tkr = yf.Ticker(symbol)
            info = tkr.info if hasattr(tkr, 'info') else {}
            return info
        except Exception as e:
            logger.debug(f"{symbol}: Error fetching info: {e}")
            return None
