#!/usr/bin/env python3
"""
bot_v2 Main Launcher - Continuous Trading Loop
================================================

Modular implementation of ShortCycleTrader with clean architecture.
Supports 3-strategy stack: Mean Reversion RSI + Gap & Go + Double Bottom

Features:
- Post-market watchlist refresh (4:00 PM)
- Premarket portfolio summary + gap scan (9:00 AM)
- Entry window (9:45-10:00 AM)
- Exit monitoring (continuous)
- Friday 3:45 PM force exit
- D+1 forced exit system

Author: LiteBotX Team
Version: 2.0 (Modular Architecture)
Date: November 24, 2025
"""

import os
import sys
import time
import logging
import datetime as dt
import pytz
import warnings
from typing import List, Optional, Dict
from pathlib import Path

# Suppress FutureWarnings from pandas and other libraries
warnings.simplefilter(action='ignore', category=FutureWarning)

# Suppress yfinance logging errors (rate limit warnings, "possibly delisted" errors)
logging.getLogger('yfinance').setLevel(logging.CRITICAL)

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("⚠️  python-dotenv not installed. Install with: pip install python-dotenv")
    print("⚠️  Continuing without .env file support...")

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Import bot_v2 modules
from bot_v2.config.trading_config import ShortCycleConfig
from bot_v2.signal_generation.signal_generator import AISignalGenerator
from bot_v2.portfolio.portfolio_manager import AIPortfolioManager
from bot_v2.execution.position_tracker import AIPositionTracker
from bot_v2.execution.order_manager import AIOrderManager
from bot_v2.execution.exit_manager import AIExitManager
from bot_v2.earnings import EarningsCalendar
from bot_v2.gap_scanner import MorningGapScanner
from bot_v2.pattern import PatternRecognizer
from bot_v2.safety import SafetyMonitor, SafetyConfig
from bot_v2.sector import SectorSpecificExitManager
from bot_v2.utils.day_trade_tracker import DayTradeTracker

# Import core LiteBotX components (for data and execution)
try:
    from bot_v2.data.data_loader import DataLoader  # Standalone bot_v2 data loader
    from logger import setup_logger
    from connect_real_trading import RealPaperTradingEngine
except ImportError as e:
    print(f"❌ Failed to import LiteBotX components: {e}")
    sys.exit(1)


class BotV2Launcher:
    """Main launcher for bot_v2 with continuous trading loop"""
    
    def __init__(self, config: Optional[ShortCycleConfig] = None, paper_trading: bool = True):
        """Initialize bot_v2 launcher
        
        Args:
            config: Trading configuration (defaults to ShortCycleConfig)
            paper_trading: True for paper trading, False for live trading
        """
        self.config = config or ShortCycleConfig()
        self.paper_trading = paper_trading
        self.logger = setup_logger("bot_v2_launcher")
        
        # Initialize timezone
        self.tz = pytz.timezone('America/New_York')
        
        # Initialize core components
        self._initialize_components()
        
        # State tracking
        self.is_running = False
        self.last_watchlist_refresh = None
        self.last_gap_scan = None
        self.last_entry_scan = None
        self.entries_today = 0
        self.last_midday_refresh = None
        
        self.logger.info("=" * 80)
        self.logger.info("🚀 bot_v2 Launcher Initialized")
        self.logger.info("=" * 80)
        self.logger.info(f"📊 Configuration:")
        self.logger.info(f"   Portfolio Value: ${self.config.portfolio_value:,.2f}")
        self.logger.info(f"   Max Universe Size: {self.config.max_universe_size}")
        self.logger.info(f"   Max Positions/Day: {self.config.max_positions_per_day}")
        self.logger.info(f"   Paper Trading: {self.paper_trading}")
        self.logger.info("=" * 80)
    
    def _initialize_components(self):
        """Initialize all bot_v2 modules"""
        try:
            # Data and execution
            self.data_loader = DataLoader()
            
            # Paper trading connection (always enabled - no simulation mode)
            if self.paper_trading:
                self.trading_engine = RealPaperTradingEngine()
                self.logger.info("✅ Connected to Alpaca Paper Trading")
            else:
                self.logger.error("❌ Live trading not implemented - use paper_trading=True")
                raise ValueError("Paper trading must be enabled")
            
            # Signal generation
            self.signal_generator = AISignalGenerator(
                config=self.config,
                price_fetcher=self._get_realtime_price
            )
            
            # Portfolio management
            self.portfolio_manager = AIPortfolioManager(config=self.config)
            self.position_tracker = AIPositionTracker(config=self.config)
            self.position_tracker.load_positions()  # Load existing positions from file
            self.order_manager = AIOrderManager(
                config=self.config,
                execution_engine=self.trading_engine  # Use real Alpaca connection, not simulator
            )
            
            # Exit manager needs stop_manager first
            from bot_v2.risk_management.stop_loss_manager import AIStopLossManager
            self.stop_manager = AIStopLossManager(config=self.config)
            
            self.exit_manager = AIExitManager(
                config=self.config,
                stop_manager=self.stop_manager,
                order_manager=self.order_manager
            )
            
            # Specialized modules
            self.earnings_calendar = EarningsCalendar(
                entry_blackout_days=3,
                exit_buffer_days=1
            )
            
            self.gap_scanner = MorningGapScanner(data_loader=self.data_loader)
            self.pattern_recognizer = PatternRecognizer()
            
            self.safety_monitor = SafetyMonitor(
                config=SafetyConfig(),
                portfolio_value=self.config.portfolio_value
            )
            
            self.sector_exit_manager = SectorSpecificExitManager()
            
            # PDT compliance
            self.day_trade_tracker = DayTradeTracker(
                max_trades=3,
                window_business_days=5
            )
            
            self.logger.info("✅ All modules initialized successfully")
            
        except Exception as e:
            self.logger.error(f"❌ Failed to initialize components: {e}")
            raise
    
    def _get_realtime_price(self, symbol: str) -> Optional[float]:
        """Get real-time price for a symbol
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Current price or None if unavailable
        """
        try:
            if self.trading_engine and hasattr(self.trading_engine, 'api'):
                quote = self.trading_engine.api.get_latest_quote(symbol)
                return quote.ap  # Ask price for buying
            return None
        except Exception as e:
            self.logger.debug(f"Failed to get realtime price for {symbol}: {e}")
            return None
    
    def _is_market_hours(self) -> bool:
        """Check if market is currently open"""
        now = dt.datetime.now(self.tz)
        
        # Weekend check
        if now.weekday() >= 5:  # Saturday=5, Sunday=6
            return False
        
        # Market hours: 9:30 AM - 4:00 PM ET
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        return market_open <= now <= market_close
    
    def _get_trading_phase(self) -> str:
        """Determine current trading phase
        
        Returns:
            'premarket', 'entry_window', 'monitoring', 'force_exit', 'postmarket', 'closed'
        """
        now = dt.datetime.now(self.tz)
        
        # Weekend
        if now.weekday() >= 5:
            return 'closed'
        
        current_time = now.time()
        
        # Premarket: 7:00 AM - 9:30 AM
        if current_time >= dt.time(7, 0) and current_time < dt.time(9, 30):
            return 'premarket'
        
        # Entry window: 9:45 AM - 10:00 AM
        if current_time >= dt.time(9, 45) and current_time < dt.time(10, 0):
            return 'entry_window'
        
        # Force exit window: 3:45 PM - 4:00 PM (Friday) or D+1 positions
        if current_time >= dt.time(15, 45) and current_time < dt.time(16, 0):
            if now.weekday() == 4:  # Friday
                return 'force_exit'
        
        # Mid-day refresh windows (if no entries): 11:00 AM, 12:00 PM, 1:00 PM
        midday_windows = [
            (dt.time(11, 0), dt.time(11, 15)),  # 11:00-11:15 AM
            (dt.time(12, 0), dt.time(12, 15)),  # 12:00-12:15 PM
            (dt.time(13, 0), dt.time(13, 15)),  # 1:00-1:15 PM
        ]
        for start, end in midday_windows:
            if start <= current_time < end:
                return 'midday_refresh'
        
        # Regular monitoring: 10:00 AM - 3:45 PM
        if current_time >= dt.time(10, 0) and current_time < dt.time(15, 45):
            return 'monitoring'
        
        # Postmarket: 4:00 PM - 7:00 PM
        if current_time >= dt.time(16, 0) and current_time < dt.time(19, 0):
            return 'postmarket'
        
        return 'closed'
    
    def _run_midday_refresh(self):
        """Run mid-day refresh if no entries were made (11 AM, 12 PM, 1 PM)"""
        now = dt.datetime.now(self.tz)
        
        # Only refresh once per window
        if self.last_midday_refresh and self.last_midday_refresh >= now.replace(minute=0, second=0, microsecond=0):
            return
        
        # Check if we have any positions entered today
        if self.entries_today > 0:
            self.logger.info(f"💼 {self.entries_today} entries made today - skipping mid-day refresh")
            return
        
        self.logger.info("=" * 80)
        self.logger.info(f"🔄 MID-DAY REFRESH ({now.strftime('%I:%M %p')}) - No entries yet today")
        self.logger.info("=" * 80)
        self.logger.info("♻️ Re-scanning universe for new opportunities...")
        
        # Run a fresh entry scan
        self._run_entry_scan()
        
        self.last_midday_refresh = now
        
        if self.entries_today == 0:
            self.logger.info("⚠️ Still no entries - will try again next window")
        else:
            self.logger.info(f"✅ Mid-day refresh successful: {self.entries_today} entries made")
    
    def _refresh_watchlist(self):
        """Refresh trading universe watchlist (postmarket)"""
        self.logger.info("=" * 80)
        self.logger.info("📋 WATCHLIST REFRESH (Postmarket)")
        self.logger.info("=" * 80)
        
        try:
            # Get universe from data loader or pre-filter
            # TODO: Integrate with PreFilter for dynamic universe
            universe = self._get_universe()
            
            self.logger.info(f"✅ Watchlist refreshed: {len(universe)} symbols")
            self.last_watchlist_refresh = dt.datetime.now(self.tz)
            
            return universe
            
        except Exception as e:
            self.logger.error(f"❌ Watchlist refresh failed: {e}")
            return []
    
    def _get_universe(self) -> List[str]:
        """Load 150-stock curated mid-cap universe from JSON"""
        import json
        from pathlib import Path
        
        try:
            universe_file = Path(__file__).parent / "data" / "mid_cap_universe.json"
            with open(universe_file) as f:
                data = json.load(f)
            
            # Flatten all sectors into single list
            all_stocks = []
            # Nov 28: Added consumer_staples, utilities, reits, dividend_aristocrats for mean-reverting stocks
            for sector in ["technology", "consumer_discretionary", "healthcare_biotech",
                           "financials", "energy_clean", "industrials", 
                           "communication", "materials_commodities",
                           "consumer_staples", "utilities", "reits", "dividend_aristocrats"]:
                all_stocks.extend(data.get(sector, []))
            
            self.logger.info(f"📊 Loaded universe: {len(all_stocks)} stocks")
            return all_stocks
        except Exception as e:
            self.logger.error(f"❌ Failed to load universe: {e}, using fallback")
            return ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA", "AMD", "NFLX", "AVGO"]
    
    def _run_premarket_scan(self):
        """Run premarket gap scan and portfolio summary"""
        self.logger.info("=" * 80)
        self.logger.info("🌅 PREMARKET SCAN (9:00 AM)")
        self.logger.info("=" * 80)
        
        try:
            # Portfolio summary
            positions = self.position_tracker.get_active_positions()
            self.logger.info(f"📊 Active Positions: {len(positions)}")
            
            for pos in positions:
                pnl_pct = ((pos.current_price - pos.entry_price) / pos.entry_price) * 100
                self.logger.info(
                    f"   {pos.symbol}: ${pos.current_price:.2f} "
                    f"({pnl_pct:+.1f}%) - Day {pos.days_held}"
                )
            
            # Gap scan (optional - requires market data API)
            if self.gap_scanner:
                try:
                    universe = self._get_universe()
                    gap_results = self.gap_scanner.scan_premarket_gaps(universe)
                    
                    if gap_results:
                        self.logger.info(f"\n📈 Gap Scan Results: {len(gap_results)} gaps detected")
                        for symbol, gap_info in gap_results.items():
                            self.logger.info(
                                f"   {symbol}: {gap_info['gap_pct']*100:+.1f}% gap, "
                                f"quality: {gap_info.get('gap_quality', 'N/A')}"
                            )
                    else:
                        self.logger.info("📊 No significant gaps detected")
                except Exception as e:
                    self.logger.warning(f"⚠️ Gap scan unavailable (market data API issue): {e}")
            
            self.last_gap_scan = dt.datetime.now(self.tz)
            
        except Exception as e:
            self.logger.error(f"❌ Premarket scan failed: {e}")
    
    def _run_entry_scan(self):
        """Run entry scan with PreFilter during entry window (9:45-10:00 AM)"""
        self.logger.info("=" * 80)
        self.logger.info("🎯 ENTRY SCAN (9:45-10:00 AM)")
        self.logger.info("=" * 80)
        
        try:
            # Get full 150-stock universe
            full_universe = self._get_universe()
            
            # Run PreFilter (3-stage: Price/Volume/Volatility)
            from bot_v2.core.pre_filter import PreFilter
            from bot_v2.config.prefilter_config import SIMPLE_PREFILTER_CONFIG
            
            prefilter = PreFilter(self.data_loader, SIMPLE_PREFILTER_CONFIG)
            candidates = prefilter.run_filter(full_universe)
            
            self.logger.info(f"📊 PreFilter: {len(candidates)} candidates from {len(full_universe)} stocks")
            
            if not candidates:
                self.logger.warning("⚠️ PreFilter returned 0 candidates")
                return
            
            # Get market data for candidates only
            market_data = {}
            for symbol in candidates:
                try:
                    data = self.data_loader.get_historical_data(symbol, days=100)
                    market_data[symbol] = data
                except Exception as e:
                    self.logger.debug(f"Failed to load data for {symbol}: {e}")
            
            # Generate signals on pre-filtered candidates
            active_positions = self.position_tracker.get_active_positions()
            signals = self.signal_generator.generate_signals(
                universe=candidates,  # Use pre-filtered candidates
                market_data=market_data,
                active_positions=active_positions
            )
            
            self.logger.info(f"✅ Generated {len(signals)} entry signals")
            
            # Track last entry scan
            now = dt.datetime.now(self.tz)
            if self.last_entry_scan is None or self.last_entry_scan.date() < now.date():
                self.entries_today = 0  # Reset daily counter
            self.last_entry_scan = now
            
            # Execute entries
            for signal in signals:
                try:
                    # PDT compliance is handled by order_manager._record_day_trade_if_needed()
                    # For D+1 strategy (max_hold_days=2), trades are NOT day trades
                    # Only intraday trades (max_hold_days=0) trigger PDT counting
                    
                    # Check earnings blackout
                    if self.earnings_calendar.should_avoid_entry(signal.symbol):
                        self.logger.warning(f"⚠️ Earnings Blackout: {signal.symbol} entry blocked")
                        continue
                    
                    # Execute entry
                    position = self.order_manager.execute_entry(signal)
                    if position:
                        self.logger.info(f"✅ Entry executed: {signal.symbol} @ ${signal.entry_price:.2f}")
                        # Track position for exits
                        self.position_tracker.add_position(position)
                        self.position_tracker.save_positions()
                        # PDT tracking is handled by order_manager._record_day_trade_if_needed()
                        # Only intraday trades (max_hold_days=0) are recorded as day trades
                        self.entries_today += 1
                    else:
                        self.logger.warning(f"⚠️ Entry rejected: {signal.symbol} (check order_manager logs for details)")
                    
                except Exception as e:
                    self.logger.error(f"❌ Entry failed for {signal.symbol}: {e}")
            
        except Exception as e:
            self.logger.error(f"❌ Entry scan failed: {e}")
    
    def _monitor_exits(self):
        """Monitor and execute exits (continuous during market hours)"""
        try:
            active_positions = self.position_tracker.get_active_positions()
            
            if not active_positions:
                return
            
            for position in active_positions:
                try:
                    # Update current price
                    current_price = self._get_realtime_price(position.symbol)
                    if current_price:
                        position.current_price = current_price
                    
                    # Check exit conditions
                    should_exit, exit_reason = self.exit_manager.should_exit(position)
                    
                    if should_exit:
                        self.logger.info(
                            f"🔔 Exit Signal: {position.symbol} - {exit_reason}"
                        )
                        
                        # Execute exit
                        success = self.order_manager.execute_sell_order(position, current_price, exit_reason)
                        if success:
                            self.logger.info(
                                f"✅ Exit executed: {position.symbol} @ ${current_price:.2f}"
                            )
                
                except Exception as e:
                    self.logger.error(f"❌ Exit monitoring failed for {position.symbol}: {e}")
        
        except Exception as e:
            self.logger.error(f"❌ Exit monitoring failed: {e}")
    
    def _force_exit_all(self, reason: str = "End of day"):
        """Force exit all positions (Friday 3:45 PM or D+1)"""
        self.logger.info("=" * 80)
        self.logger.info(f"🚨 FORCE EXIT: {reason}")
        self.logger.info("=" * 80)
        
        try:
            active_positions = self.position_tracker.get_active_positions()
            
            for position in active_positions:
                try:
                    self.logger.info(f"🔴 Force exiting: {position.symbol}")
                    # Get current price
                    current_price = self._get_realtime_price(position.symbol)
                    if not current_price:
                        current_price = position.entry_price
                    
                    success = self.order_manager.execute_sell_order(position, current_price, reason)
                    if success:
                        self.logger.info(f"✅ {position.symbol} exited @ ${current_price:.2f}")
                except Exception as e:
                    self.logger.error(f"❌ Force exit failed for {position.symbol}: {e}")
        
        except Exception as e:
            self.logger.error(f"❌ Force exit failed: {e}")
    
    def run_continuous_loop(self):
        """Run continuous trading loop with phase-based execution"""
        self.is_running = True
        self.logger.info("🔄 Starting continuous trading loop...")
        
        try:
            while self.is_running:
                # Get current trading phase
                phase = self._get_trading_phase()
                
                if phase == 'premarket':
                    # Run premarket scan once per day
                    if self.last_gap_scan is None or \
                       self.last_gap_scan.date() < dt.datetime.now(self.tz).date():
                        self._run_premarket_scan()
                    self._countdown_sleep(60, "⏰ Premarket - Next check in")
                
                elif phase == 'entry_window':
                    # Run entry scan
                    self._run_entry_scan()
                    self._countdown_sleep(300, "⏰ Entry Window - Next scan in")  # Scan every 5 minutes
                
                elif phase == 'midday_refresh':
                    # Run mid-day refresh if no entries made
                    self._run_midday_refresh()
                    self._countdown_sleep(300, "⏰ Midday Refresh - Next check in")
                
                elif phase == 'monitoring':
                    # Monitor exits continuously
                    self._monitor_exits()
                    self._countdown_sleep(60, "⏰ Monitoring Exits - Next check in")
                
                elif phase == 'force_exit':
                    # Force exit (Friday or D+1)
                    now = dt.datetime.now(self.tz)
                    if now.weekday() == 4:  # Friday
                        self._force_exit_all("Friday 3:45 PM - No weekend holds")
                    else:
                        # Check for D+1 positions
                        # TODO: Implement D+1 check logic
                        pass
                    self._countdown_sleep(300, "⏰ Force Exit Window - Next check in")
                
                elif phase == 'postmarket':
                    # Refresh watchlist once per day
                    if self.last_watchlist_refresh is None or \
                       self.last_watchlist_refresh.date() < dt.datetime.now(self.tz).date():
                        self._refresh_watchlist()
                    self._countdown_sleep(300, "⏰ Postmarket - Next check in")
                
                else:  # closed
                    self.logger.info("💤 Market closed - waiting for next session")
                    self._countdown_sleep(600, "⏰ Market Closed - Next check in")
        
        except KeyboardInterrupt:
            self.logger.info("\n⚠️ Received shutdown signal")
            self.shutdown()
        except Exception as e:
            self.logger.error(f"❌ Critical error in main loop: {e}")
            self.shutdown()
    
    def _countdown_sleep(self, seconds: int, message: str):
        """
        Sleep with countdown status updates.
        
        Args:
            seconds: Total seconds to sleep
            message: Status message to display
        """
        if seconds <= 60:
            # For short sleeps, just display once
            mins = seconds / 60
            self.logger.info(f"{message} {mins:.1f} minutes")
            time.sleep(seconds)
        else:
            # For longer sleeps, show countdown updates
            remaining = seconds
            while remaining > 0:
                mins = remaining / 60
                self.logger.info(f"{message} {mins:.1f} minutes")
                
                # Sleep in 60-second chunks
                sleep_time = min(60, remaining)
                time.sleep(sleep_time)
                remaining -= sleep_time
    
    def shutdown(self):
        """Graceful shutdown"""
        self.logger.info("=" * 80)
        self.logger.info("🛑 SHUTTING DOWN bot_v2")
        self.logger.info("=" * 80)
        
        self.is_running = False
        
        # Force exit all positions (safety)
        self._force_exit_all("Emergency shutdown")
        
        self.logger.info("✅ Shutdown complete")


def main():
    """Main entry point"""
    print("=" * 80)
    print("🚀 bot_v2 OPTIMIZED - Mean Reversion Strategy")
    print("=" * 80)
    print("")
    print("Configuration:")
    print("  - Strategy: Mean Reversion RSI (56% WR - Proven)")
    print("  - Universe: 150 curated mid-cap stocks")
    print("  - PreFilter: 3-stage simplified (Price/Volume/Volatility)")
    print("  - Max Positions: 12 concurrent")
    print("  - Force Exit: 2:30 PM (improved from 3:45 PM)")
    print("  - Adaptive: Mid-day refresh at 11 AM, 12 PM, 1 PM if no entries")
    print("  - Confidence: 50% threshold")
    print("  - Expected: 25-35 candidates, 2.5-3.5% weekly returns")
    print("")
    print("=" * 80)
    print("")
    
    # Initialize launcher
    config = ShortCycleConfig()
    launcher = BotV2Launcher(config=config, paper_trading=True)
    
    # Run continuous loop
    launcher.run_continuous_loop()


if __name__ == "__main__":
    main()
