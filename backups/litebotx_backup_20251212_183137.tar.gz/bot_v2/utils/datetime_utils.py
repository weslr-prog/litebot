"""
Datetime utilities for trading operations
"""
import datetime as dt
from typing import Optional


def get_next_trading_day(current_date: dt.date) -> dt.date:
    """
    Get next trading day for D+1 exit scheduling.
    
    Args:
        current_date: Starting date
        
    Returns:
        Next trading day (skips weekends)
    """
    next_day = current_date + dt.timedelta(days=1)
    # Simple weekend handling
    if next_day.weekday() >= 5:  # Weekend
        next_day = current_date + dt.timedelta(days=3 if current_date.weekday() == 4 else 1)
    return next_day


def calculate_hold_days(entry_date: dt.date, exit_date: Optional[dt.date] = None) -> int:
    """
    Calculate number of days position was held.
    
    Args:
        entry_date: Position entry date
        exit_date: Position exit date (defaults to today)
        
    Returns:
        Number of days held
    """
    if exit_date is None:
        exit_date = dt.date.today()
    return (exit_date - entry_date).days
