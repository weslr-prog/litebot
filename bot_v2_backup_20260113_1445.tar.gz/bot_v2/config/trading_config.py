"""
Configuration module for bot_v2
Extracted from traders/short_cycle_trader.py
"""

from dataclasses import dataclass
from typing import List


@dataclass
class ShortCycleConfig:
    """Configuration for short-cycle trading system"""
    # Portfolio parameters (OPTION 3: Triple Frequency + 60% Win Rate - $1K Portfolio)
    # Jan 13: Increased position size from $50 to $80 for better capital utilization
    portfolio_value: float = None  # Will be fetched from Alpaca account (default: 1000.0 if fetch fails)
    daily_pool_percent: float = 0.30  # 30% Mon-Wed (90% by Wed), 100% Thu-Fri (aggressive finish)
    max_risk_per_trade_dollars: float = 20.0  # Risk per trade for position sizing (2% of $1K)
    max_position_dollars: float = 80.0  # Issue 5.2: $80 per position (was $50) for better returns
    max_loss_per_trade_dollars: float = 20.0  # Hard stop at $20 per trade (2% of portfolio)
    
    # Market cap filter (mid-cap only)
    min_market_cap: float = 2_000_000_000  # $2B minimum (mid-cap floor)
    max_market_cap: float = 10_000_000_000  # $10B maximum (mid-cap ceiling)
    
    # Position parameters - reduced max positions to account for larger position size
    max_positions_per_day: int = 10  # Issue 5.2: 10 positions × $80 = $800 max exposure (was 12×$50=$600)
    min_position_size_dollars: float = 10.0  # Minimum viable position for $1K account
    max_position_size_percent: float = 0.20  # 20% max position size (hard cap at $200 enforced)
    max_universe_size: int = 500  # Maximum number of symbols in trading universe (scaled for 3-strategy stack)
    
    # Diversification parameters
    max_positions_per_symbol_small: int = 2  # Max positions per symbol for portfolios < $100K
    max_positions_per_symbol_large: int = 3  # Max positions per symbol for portfolios > $100K
    max_concentration_percent_small: float = 0.35  # Max 35% of positions in one symbol (small portfolios)
    max_concentration_percent_large: float = 0.40  # Max 40% of positions in one symbol (large portfolios)
    portfolio_threshold_large: float = 100000.0  # Threshold for "large" portfolio diversification rules
    
    # Time parameters (Smart D+1 Exit Strategy - Dec 30, 2025)
    max_hold_days: int = 2  # Maximum 2 days hold (D+1 forced exit)
    default_hold_days: int = 1  # Default to 1 day hold for D+1 strategy
    trading_days: List[str] = None  # All trading days (Mon-Fri)
    exit_time: str = "15:45"  # 15 minutes before close - HARD EXIT for all positions
    d_plus_one_force_exit_time: str = "12:00"  # Smart D+1: Exit by noon (9:30-12:00 window for optimal exit)
    d_plus_one_smart_exit_enabled: bool = True  # Enable smart D+1 exits (exit on profit or >1% loss, else wait till noon)
    friday_force_exit_time: str = "15:45"  # Force exit all Friday positions (no weekend holds)
    
    # PDT (Pattern Day Trader) management
    max_emergency_exits_per_week: int = 3  # 3 same-day exits allowed per week
    allow_friday_entries_with_unused_slots: bool = True  # Use unused emergency slots on Friday
    
    # Profit targets (Dual-Strategy System optimized for D+1 overnight holds - Jan 2026)
    profit_target_pct: float = 0.02  # 2% profit target (lowered from 3% for quick exits)
    
    # Risk parameters (Dual-Strategy System: Gap & Go + Fade/Short)
    max_daily_loss_percent: float = 0.08  # 8% daily loss limit
    max_weekly_loss_percent: float = 0.15   # 15% weekly loss limit
    confidence_threshold: float = 0.25  # 25% minimum confidence (Jan 6: lowered from 50% to match RSI<35 filter intent)
    
    # Dual-Strategy Configuration (Jan 13, 2026: 80/20 allocation based on backtest performance)
    # Gap & Go: 830% return / 748 trades = 1.11% per trade
    # Fade/Short: 174% return / 914 trades = 0.19% per trade
    # Gap & Go is 5.8x more profitable per trade → allocate more capital
    enable_gap_and_go: bool = True  # Primary strategy: Morning gap entries (80% capital)
    enable_fade_short: bool = True  # Backup strategy: Overbought reversals (20% capital)
    gap_and_go_allocation: float = 0.80  # Issue 5.1: 80% to Gap & Go (was 70%)
    fade_short_allocation: float = 0.20  # Issue 5.1: 20% to Fade/Short (was 30%)
    gap_and_go_priority: bool = True  # Gap & Go wins conflicts (same stock, same day)
    
    # Strategy-specific profit/stop targets (Jan 8, 2026: Gap & Go + Fade/Short)
    gap_and_go_profit_target_pct: float = 0.03  # 3% profit target for gap & go (backtest validated)
    gap_and_go_stop_loss_pct: float = 0.02  # 2% stop loss for gap & go
    fade_short_profit_target_pct: float = 0.02  # 2% profit target for fade/short (quick reversals)
    fade_short_stop_loss_pct: float = 0.015  # 1.5% stop loss for fade/short (tight stops)
    
    # Gap & Go parameters
    gap_min_pct: float = 0.02  # Minimum 2% gap
    gap_max_pct: float = 0.08  # Maximum 8% gap (avoid gap-and-crash)
    gap_rsi_max: float = 75.0  # RSI must be < 75 at gap (not too overbought)
    gap_scan_time: str = "09:35"  # Scan for gaps 5 mins after open
    
    # Fade/Short parameters
    fade_rsi_min: float = 70.0  # RSI must be > 70 (overbought)
    fade_extension_min_pct: float = 0.10  # Must be 10%+ above 20-SMA
    fade_scan_start: str = "10:00"  # Start scanning after morning volatility
    fade_scan_end: str = "14:00"  # Stop scanning before close
    
    # Default targets (Nov 28: Updated for 2:1 R:R ratio)
    profit_target_pct: float = 0.04  # 4% default profit target (raised from 3%)
    stop_loss_pct: float = 0.02  # 2% default stop loss (tightened from 3%)
    
    # Trailing Stop Parameters (Optimized Jan 13, 2026 - earlier activation)
    enable_trailing_stops: bool = True  # Enable trailing stop system
    trailing_trigger_pct: float = 0.015  # Activate after +1.5% gain (lowered from 2% to capture more gains)
    trailing_distance_pct: float = 0.01  # Trail by 1.0% (tightened from 1.5%)
    trailing_min_profit_pct: float = 0.005  # Lock in minimum +0.5% profit once activated
    trailing_update_interval_sec: int = 60  # Update trailing stops every 60 seconds
    
    # Backtesting parameters
    enable_forced_d1_exit: bool = True  # ENABLED - D+1 forced exits at 3:45 PM
    model_transaction_costs: bool = True
    commission_per_trade: float = 0.0  # Assume commission-free
    spread_bp: float = 5.0  # 5 basis points spread cost
    
    def __post_init__(self):
        if self.trading_days is None:
            self.trading_days = ["monday", "tuesday", "wednesday", "thursday"]
        
        # Fetch real account equity if not set
        if self.portfolio_value is None:
            self.portfolio_value = self._fetch_account_equity()
        
        # Calculate derived values
        self.daily_pool_dollars = self.portfolio_value * self.daily_pool_percent
        self.max_daily_loss_dollars = self.portfolio_value * self.max_daily_loss_percent
        self.max_weekly_loss_dollars = self.portfolio_value * self.max_weekly_loss_percent
    
    def _fetch_account_equity(self) -> float:
        """Fetch actual account equity from Alpaca"""
        try:
            import os
            from alpaca.trading.client import TradingClient
            
            api_key = os.getenv('APCA_API_KEY_ID')
            api_secret = os.getenv('APCA_API_SECRET_KEY')
            
            if not api_key or not api_secret:
                print("⚠️  Alpaca credentials not found, using default $1000")
                return 1000.0
            
            client = TradingClient(api_key, api_secret, paper=True)
            account = client.get_account()
            equity = float(account.equity)
            
            print(f"✅ Fetched account equity: ${equity:,.2f}")
            return equity
            
        except Exception as e:
            print(f"⚠️  Failed to fetch account equity: {e}")
            print("   Using default $1000")
            return 1000.0
    
    def validate(self) -> bool:
        """Validate configuration parameters"""
        errors = []
        
        # Portfolio validation
        if self.portfolio_value <= 0:
            errors.append("portfolio_value must be positive")
        if not 0 < self.daily_pool_percent <= 1.0:
            errors.append("daily_pool_percent must be between 0 and 1")
        if self.max_position_dollars > self.portfolio_value:
            errors.append("max_position_dollars cannot exceed portfolio_value")
        
        # Risk validation
        if not 0 < self.confidence_threshold <= 1.0:
            errors.append("confidence_threshold must be between 0 and 1")
        if self.max_daily_loss_percent < 0:
            errors.append("max_daily_loss_percent must be non-negative")
        
        # Position validation
        if self.max_positions_per_day < 1:
            errors.append("max_positions_per_day must be at least 1")
        if self.min_position_size_dollars > self.max_position_dollars:
            errors.append("min_position_size_dollars cannot exceed max_position_dollars")
        
        if errors:
            raise ValueError(f"Configuration validation failed: {', '.join(errors)}")
        
        return True
    
    def get_dynamic_confidence_threshold(self, active_position_count: int) -> float:
        """
        Issue 3.1: Dynamic confidence threshold based on position count.
        
        When portfolio has few positions, accept lower confidence signals.
        When portfolio is filling up, require higher quality signals.
        This naturally filters to better trades as positions accumulate.
        
        Args:
            active_position_count: Number of currently active positions
            
        Returns:
            Adjusted confidence threshold (0.25 to 0.55)
        """
        fill_ratio = active_position_count / self.max_positions_per_day
        
        if fill_ratio < 0.25:
            # Few positions: Accept base threshold (need trades)
            return self.confidence_threshold  # 0.25
        elif fill_ratio < 0.50:
            # Half full: Standard threshold
            return max(0.35, self.confidence_threshold)
        elif fill_ratio < 0.75:
            # Mostly full: Higher threshold
            return max(0.45, self.confidence_threshold)
        else:
            # Nearly full: Only best signals
            return max(0.55, self.confidence_threshold)
    
    def get_market_condition_allocation(self, vix_level: float = 20.0, 
                                         spy_momentum: float = 0.0) -> tuple:
        """
        Issue 5.3: Adjust Gap & Go / Fade allocation based on market conditions.
        
        In bullish, low-volatility markets: Favor Gap & Go (momentum continuation)
        In bearish, high-volatility markets: Favor Fade/Short (mean reversion)
        
        Args:
            vix_level: Current VIX level (default 20 = neutral)
            spy_momentum: SPY % change over last 5 days (positive = bullish)
            
        Returns:
            Tuple of (gap_and_go_allocation, fade_short_allocation)
        """
        base_gap = self.gap_and_go_allocation  # 0.80
        base_fade = self.fade_short_allocation  # 0.20
        
        # VIX adjustment
        # Low VIX (<15): Favor Gap & Go (calm market, momentum works)
        # High VIX (>30): Favor Fade/Short (volatile market, reversals work)
        vix_adjustment = 0.0
        if vix_level < 15:
            vix_adjustment = 0.10  # Boost Gap & Go by 10%
        elif vix_level > 30:
            vix_adjustment = -0.15  # Reduce Gap & Go by 15% (favor Fade)
        elif vix_level > 25:
            vix_adjustment = -0.10  # Moderate reduction
        
        # SPY momentum adjustment
        # Strong bullish momentum: Favor Gap & Go
        # Strong bearish momentum: Favor Fade/Short
        momentum_adjustment = 0.0
        if spy_momentum > 0.02:  # SPY up >2% in 5 days
            momentum_adjustment = 0.05  # Slight boost to Gap & Go
        elif spy_momentum < -0.02:  # SPY down >2% in 5 days
            momentum_adjustment = -0.10  # Reduce Gap & Go, favor Fade
        elif spy_momentum < -0.05:  # SPY down >5% in 5 days (correction)
            momentum_adjustment = -0.20  # Strong shift to Fade
        
        # Apply adjustments with bounds
        gap_allocation = min(max(base_gap + vix_adjustment + momentum_adjustment, 0.50), 0.90)
        fade_allocation = 1.0 - gap_allocation
        
        return (gap_allocation, fade_allocation)
